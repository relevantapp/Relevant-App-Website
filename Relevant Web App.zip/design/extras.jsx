/* Marketing homepage, Auth, Mobile views, and the Prototype Shell */

// ───────────────────────── Marketing ─────────────────────────
function Marketing() {
  return (
    <div style={{ background: "var(--bg)", minHeight: "100%", position: "relative" }}>
      {/* Nav */}
      <div style={{ position: "sticky", top: 0, background: "color-mix(in oklch, var(--bg), transparent 20%)", backdropFilter: "blur(20px)", borderBottom: "1px solid var(--border)", padding: "14px 40px", display: "flex", justifyContent: "space-between", alignItems: "center", zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {I.logo(22)}
          <span className="mono" style={{ fontSize: 12, letterSpacing: "0.12em", color: "var(--ink)" }}>RELEVANT</span>
        </div>
        <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
          {["Product","Intelligence","Pricing","Customers","Changelog"].map(x => (
            <a key={x} style={{ fontSize: 13, color: "var(--ink-dim)" }}>{x}</a>
          ))}
          <Btn variant="ghost" size="sm">Sign in</Btn>
          <Btn variant="amber" size="sm">Get started</Btn>
        </div>
      </div>

      {/* Hero */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "96px 40px 72px", position: "relative" }}>
        <Kicker color="var(--amber)">The relevance engine · v4</Kicker>
        <h1 className="display" style={{ fontSize: 104, fontWeight: 400, lineHeight: 0.95, letterSpacing: "-0.035em", marginTop: 20, maxWidth: 1100 }}>
          The world moves <em style={{ fontStyle: "italic", color: "var(--amber)" }}>loudly</em>.<br/>
          Only some of it is <em style={{ fontStyle: "italic" }}>yours</em>.
        </h1>
        <p style={{ fontSize: 19, color: "var(--ink-dim)", maxWidth: 620, lineHeight: 1.5, marginTop: 28 }}>
          Relevant reads the internet the way a good analyst would — ranked by consequence to <em>your</em> decisions, sourced to the original, shaped for the room you're walking into.
        </p>
        <div style={{ marginTop: 36, display: "flex", gap: 12, alignItems: "center" }}>
          <Btn variant="amber" size="lg" icon={<I.arrowR size={14} />}>Start free — 14 day trial</Btn>
          <Btn variant="ghost" size="lg">Watch 90s demo</Btn>
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginLeft: 16 }}>no credit card · cancel any time</span>
        </div>

        {/* Showcase frame */}
        <div style={{ marginTop: 72, position: "relative", borderRadius: 16, border: "1px solid var(--border-strong)", overflow: "hidden", background: "var(--bg-elev)", boxShadow: "0 30px 80px -20px rgba(0,0,0,0.6)" }}>
          <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 6, background: "var(--surface)" }}>
            <Dot size={10} color="#ff5f56" /><Dot size={10} color="#ffbd2e" /><Dot size={10} color="#27c93f" />
            <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", margin: "0 auto" }}>app.relevant.ai — Meeting Prep · Anthropic</div>
          </div>
          <div style={{ transform: "scale(0.6)", transformOrigin: "top left", width: "166.7%", height: 660, overflow: "hidden", pointerEvents: "none" }}>
            <ResultHybrid />
          </div>
        </div>
      </div>

      {/* 3-panel value prop */}
      <div style={{ borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)", background: "var(--bg-elev)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "72px 40px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 48 }}>
          {[
            { k: "What changed", v: "Tracked continuously, ranked by consequence — not recency.", n: "01" },
            { k: "Why it matters", v: "Synthesis tied to your lens. Every sentence carries evidence.", n: "02" },
            { k: "What to do", v: "Decision-grade briefs: Meeting Prep, Business Case, Competitive. In under 3 minutes.", n: "03" },
          ].map(c => (
            <div key={c.n}>
              <div className="display tnum" style={{ fontSize: 40, fontWeight: 300, color: "var(--amber)", letterSpacing: "-0.02em" }}>{c.n}</div>
              <div className="display" style={{ fontSize: 26, fontWeight: 400, marginTop: 14, letterSpacing: "-0.01em" }}>{c.k}</div>
              <p style={{ fontSize: 15, color: "var(--ink-dim)", lineHeight: 1.55, marginTop: 10 }}>{c.v}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Workflow showcase */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "96px 40px" }}>
        <Kicker color="var(--amber)">Four workflows · one engine</Kicker>
        <h2 className="display" style={{ fontSize: 56, fontWeight: 400, marginTop: 12, lineHeight: 1.05, letterSpacing: "-0.02em", maxWidth: 800 }}>
          Shaped for the decision, not the search bar.
        </h2>
        <div style={{ marginTop: 56, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          {[
            { t: "Meeting Prep", d: "Walk in already knowing what matters — background, talking points, landmines, questions.", ic: I.briefcase, a: "var(--amber)" },
            { t: "Competitive Analysis", d: "Where they win. Where they're exposed. Source-by-source, not vibes.", ic: I.swords, a: "var(--green)" },
            { t: "Business Case", d: "Proof points, objections, what has to be true. For the deck you'll actually defend.", ic: I.target, a: "var(--amber)" },
            { t: "Market Research", d: "Landscape, demand signals, motion. In the time it takes to drink coffee.", ic: I.compass, a: "var(--green)" },
          ].map(w => (
            <Card key={w.t} style={{ padding: "32px 32px 28px" }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: `color-mix(in oklch, ${w.a}, transparent 82%)`, color: w.a, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20 }}>
                <w.ic size={20} />
              </div>
              <div className="display" style={{ fontSize: 24, fontWeight: 400, letterSpacing: "-0.01em" }}>{w.t}</div>
              <div style={{ fontSize: 14, color: "var(--ink-dim)", marginTop: 10, lineHeight: 1.55 }}>{w.d}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* Logos */}
      <div style={{ borderTop: "1px solid var(--border)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 40px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 24 }}>
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", letterSpacing: "0.1em" }}>USED BY TEAMS AT</span>
          {["STRIPE","DATABRICKS","BRAZE","RAMP","LINEAR","NOTION","SCALE"].map(l => (
            <span key={l} className="display" style={{ fontSize: 22, fontWeight: 500, color: "var(--ink-soft)", letterSpacing: "0.04em" }}>{l}</span>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "96px 40px" }}>
        <div style={{ padding: "72px 64px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 20, position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(600px 300px at 80% 20%, color-mix(in oklch, var(--amber), transparent 85%), transparent)" }} />
          <div style={{ position: "relative" }}>
            <h2 className="display" style={{ fontSize: 64, fontWeight: 400, lineHeight: 1.05, letterSpacing: "-0.02em" }}>
              Stop reading everything.<br/>
              <em style={{ color: "var(--amber)" }}>Read what matters.</em>
            </h2>
            <div style={{ marginTop: 32, display: "flex", gap: 12 }}>
              <Btn variant="amber" size="lg" icon={<I.arrowR size={14} />}>Start free</Btn>
              <Btn variant="ghost" size="lg">Talk to us</Btn>
            </div>
          </div>
        </div>
      </div>

      <div style={{ borderTop: "1px solid var(--border)", padding: "24px 40px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {I.logo(18)}
          <span className="mono" style={{ fontSize: 11, letterSpacing: "0.1em", color: "var(--ink-muted)" }}>RELEVANT · © 2026</span>
        </div>
        <div style={{ display: "flex", gap: 18 }}>
          {["Privacy","Terms","Status","Security","Changelog"].map(x => <a key={x} className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>{x}</a>)}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Auth ─────────────────────────
function Auth() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", minHeight: "100%" }}>
      <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", padding: "64px 64px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 48 }}>
          {I.logo(24)}
          <span className="mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--ink)" }}>RELEVANT</span>
        </div>
        <Kicker color="var(--amber)">Sign in</Kicker>
        <h1 className="display" style={{ fontSize: 44, fontWeight: 400, marginTop: 10, lineHeight: 1.05, letterSpacing: "-0.02em" }}>Welcome back.</h1>
        <p style={{ color: "var(--ink-muted)", marginTop: 12, fontSize: 15 }}>The world moved while you were gone. Let's catch you up.</p>

        <div style={{ marginTop: 40, display: "flex", flexDirection: "column", gap: 10 }}>
          <Btn variant="solid" size="lg" style={{ width: "100%", justifyContent: "center" }} icon={<span style={{ fontFamily: "var(--font-mono)", fontSize: 14 }}>G</span>}>Continue with Google</Btn>
          <Btn variant="solid" size="lg" style={{ width: "100%", justifyContent: "center" }} icon={<span style={{ fontSize: 14 }}></span>}>Continue with Apple</Btn>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "28px 0" }}>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
          <span className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", letterSpacing: "0.1em" }}>OR</span>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        </div>

        <div>
          <label style={{ display: "block", fontSize: 12, color: "var(--ink-muted)", marginBottom: 6 }}>Work email</label>
          <input placeholder="you@company.com" style={{ width: "100%", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 10, padding: "13px 16px", color: "var(--ink)", fontSize: 15, outline: "none" }} />
          <Btn variant="amber" size="lg" style={{ width: "100%", justifyContent: "center", marginTop: 14 }} icon={<I.arrowR size={14} />}>Continue with email</Btn>
        </div>

        <div className="mono" style={{ marginTop: 40, fontSize: 11, color: "var(--ink-muted)" }}>
          New to Relevant? <a style={{ color: "var(--amber)", textDecoration: "underline" }}>Create an account</a>
        </div>
      </div>

      <div style={{ background: "var(--bg-elev)", borderLeft: "1px solid var(--border)", padding: "64px 56px", display: "flex", flexDirection: "column", justifyContent: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(500px 300px at 20% 40%, color-mix(in oklch, var(--amber), transparent 92%), transparent)" }} />
        <div style={{ position: "relative" }}>
          <Kicker>Today · live</Kicker>
          <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 10 }}>
            {FEED_SIGNALS.slice(0, 3).map(s => (
              <div key={s.id} style={{ padding: "18px 20px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)">{s.trajectory}</Pill>
                  <span className="mono" style={{ fontSize: 10, color: "var(--ink-muted)" }}>{s.date}</span>
                </div>
                <div className="display" style={{ fontSize: 17, fontWeight: 500, lineHeight: 1.35 }}>{s.headline}</div>
                <div style={{ fontSize: 13, color: "var(--ink-dim)", marginTop: 8, lineHeight: 1.5 }}>{s.synthesis.split(".")[0]}.</div>
              </div>
            ))}
          </div>
          <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 20, letterSpacing: "0.08em" }}>SAMPLE FEED · FOUNDER · GTM · AI INFRA</div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Mobile: iPhone feed ─────────────────────────
function MobileFeed() {
  return (
    <div style={{ maxWidth: 380, margin: "20px auto", background: "var(--bg)", borderRadius: 36, border: "1px solid var(--border-strong)", overflow: "hidden", boxShadow: "0 20px 50px -10px rgba(0,0,0,0.4)" }}>
      <div style={{ height: 44, background: "var(--bg-elev)", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 24px", borderBottom: "1px solid var(--border)" }}>
        <span className="mono" style={{ fontSize: 12, color: "var(--ink)" }}>9:41</span>
        <div style={{ width: 80, height: 20, background: "var(--ink)", borderRadius: 12 }} />
        <span className="mono" style={{ fontSize: 11, color: "var(--ink)" }}>••• 5G</span>
      </div>
      <div style={{ padding: "20px 20px 16px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <Kicker>April 18 · Fri</Kicker>
          <div className="display" style={{ fontSize: 22, fontWeight: 400, marginTop: 2 }}>Today's feed</div>
        </div>
        <div style={{ width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg, var(--amber), var(--green))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 500, color: "var(--bg)" }}>AS</div>
      </div>
      <div style={{ padding: "12px 14px 20px", display: "flex", flexDirection: "column", gap: 10, background: "var(--bg)" }}>
        {FEED_SIGNALS.slice(0, 4).map(s => (
          <div key={s.id} style={{ padding: "16px 16px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)">{s.trajectory}</Pill>
              <span className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginLeft: "auto" }}>{s.date}</span>
            </div>
            <div className="display" style={{ fontSize: 15, fontWeight: 500, lineHeight: 1.3 }}>{s.headline}</div>
            <div style={{ fontSize: 12, color: "var(--ink-dim)", marginTop: 8, lineHeight: 1.5 }}>{s.synthesis}</div>
            <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
              <span className="mono" style={{ fontSize: 10, color: "var(--ink-muted)" }}>{s.sources} src</span>
              <span className="mono" style={{ fontSize: 10, color: "var(--amber)", marginLeft: "auto" }}>{s.score}</span>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: "12px 20px", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "space-around", background: "var(--bg-elev)" }}>
        {[["Feed", I.feed, true],["Intel", I.brain],["Ask", I.ask],["You", I.user]].map(([t, Ic, a], i) => (
          <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <Ic size={20} stroke={a ? "var(--amber)" : "var(--ink-muted)"} />
            <span className="mono" style={{ fontSize: 9, color: a ? "var(--amber)" : "var(--ink-muted)" }}>{t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Mobile: Intel result
function MobileIntel() {
  const b = MEETING_BRIEF;
  return (
    <div style={{ maxWidth: 380, margin: "20px auto", background: "var(--bg)", borderRadius: 36, border: "1px solid var(--border-strong)", overflow: "hidden", boxShadow: "0 20px 50px -10px rgba(0,0,0,0.4)" }}>
      <div style={{ height: 44, background: "var(--bg-elev)", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 24px", borderBottom: "1px solid var(--border)" }}>
        <span className="mono" style={{ fontSize: 12, color: "var(--ink)" }}>9:41</span>
        <div style={{ width: 80, height: 20, background: "var(--ink)", borderRadius: 12 }} />
        <span className="mono" style={{ fontSize: 11, color: "var(--ink)" }}>••• 5G</span>
      </div>
      <div style={{ padding: "18px 20px 16px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <LogoChip name={b.account} color={b.snapshot.logoColor} size={32} />
          <div>
            <Kicker color="var(--amber)">Meeting prep</Kicker>
            <div className="display" style={{ fontSize: 18, fontWeight: 500, marginTop: 2 }}>{b.account}</div>
          </div>
        </div>
      </div>
      <div style={{ padding: "20px 20px 24px" }}>
        <div className="display" style={{ fontSize: 20, fontWeight: 500, lineHeight: 1.25, letterSpacing: "-0.01em" }}>{b.bottomLine}</div>
        <div style={{ marginTop: 14, padding: "12px 14px", background: "var(--amber-soft)", borderLeft: "2px solid var(--amber)", borderRadius: "0 8px 8px 0" }}>
          <Kicker color="var(--amber)">Why it matters</Kicker>
          <div style={{ fontSize: 12.5, color: "var(--ink)", marginTop: 6, lineHeight: 1.5 }}>{b.why}</div>
        </div>
        <div style={{ marginTop: 22 }}>
          <Kicker>Talking points</Kicker>
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
            {b.talkingPoints.slice(0, 3).map((t, i) => (
              <div key={i} style={{ display: "flex", gap: 10, padding: "10px 12px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 8 }}>
                <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-muted)", paddingTop: 2 }}>{i + 1}</span>
                <div style={{ fontSize: 12.5, color: "var(--ink)", lineHeight: 1.4 }}>{t.text}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ marginTop: 22, display: "flex", gap: 8 }}>
          <Btn variant="amber" size="sm" style={{ flex: 1, justifyContent: "center" }} icon={<I.share size={12} />}>Share</Btn>
          <Btn variant="solid" size="sm" style={{ flex: 1, justifyContent: "center" }} icon={<I.ask size={12} />}>Ask</Btn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Marketing, Auth, MobileFeed, MobileIntel });
