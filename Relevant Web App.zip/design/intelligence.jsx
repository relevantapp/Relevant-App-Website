/* Intelligence screens — picker, intake, refined intent, activity, results (3 variants), history, share */

// ───────────────────────── 1. Workflow Picker ─────────────────────────
function IntelligencePicker({ onSelect }) {
  const workflows = [
    { id: "meeting", icon: I.briefcase, title: "Meeting Prep", lede: "Walk in already knowing what matters.", ex: "Anthropic · partnership intro", meta: "~1m 45s · 8–12 sources", accent: "var(--amber)" },
    { id: "competitive", icon: I.swords, title: "Competitive Analysis", lede: "Where they win. Where they're exposed.", ex: "Cursor vs Copilot · positioning", meta: "~2m 10s · 12–18 sources", accent: "var(--green)" },
    { id: "business", icon: I.target, title: "Business Case", lede: "Proof points. Objections. What has to be true.", ex: "Launch weekend delivery · East Coast", meta: "~2m 30s · 14–20 sources", accent: "var(--amber)" },
    { id: "market", icon: I.compass, title: "Market Research", lede: "Landscape, demand signals, motion.", ex: "Agent payments · infra category", meta: "~2m 15s · 15–22 sources", accent: "var(--green)" },
  ];
  return (
    <div style={{ maxWidth: 1040, margin: "0 auto", padding: "64px 48px 48px" }}>
      <div style={{ display: "flex", alignItems: "end", justifyContent: "space-between", marginBottom: 48 }}>
        <div>
          <Kicker>Intelligence · v4</Kicker>
          <h1 className="display" style={{ fontSize: 56, fontWeight: 400, marginTop: 12, lineHeight: 1.02, maxWidth: 680 }}>
            What decision are you preparing for?
          </h1>
          <p style={{ color: "var(--ink-muted)", marginTop: 14, fontSize: 16, maxWidth: 540, lineHeight: 1.5 }}>
            Pick a workflow. Answer a few structured questions. Get decision-grade signal — ranked, sourced, and shaped for your role.
          </p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Btn variant="ghost" size="sm" icon={<I.history size={14} />}>History</Btn>
          <Btn variant="ghost" size="sm" icon={<I.book size={14} />}>How it works</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--border)", border: "1px solid var(--border)", borderRadius: 14, overflow: "hidden" }}>
        {workflows.map((w) => (
          <button key={w.id} onClick={() => onSelect(w.id)} className="hoverable" style={{
            background: "var(--bg-elev)", padding: "32px 28px 28px", textAlign: "left",
            display: "flex", flexDirection: "column", gap: 20, minHeight: 220, transition: "background 0.2s ease",
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = "var(--surface)"}
          onMouseLeave={(e) => e.currentTarget.style.background = "var(--bg-elev)"}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: `color-mix(in oklch, ${w.accent}, transparent 82%)`, color: w.accent, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <w.icon size={18} />
              </div>
              <I.arrowR size={18} stroke="var(--ink-muted)" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 22, fontWeight: 500, color: "var(--ink)", marginBottom: 6 }}>{w.title}</div>
              <div style={{ fontSize: 14, color: "var(--ink-muted)", lineHeight: 1.5 }}>{w.lede}</div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", paddingTop: 16, borderTop: "1px solid var(--border)" }}>
              <div>
                <Kicker>Example</Kicker>
                <div className="mono" style={{ fontSize: 12, color: "var(--ink-dim)", marginTop: 4 }}>{w.ex}</div>
              </div>
              <div className="mono" style={{ fontSize: 10, color: "var(--ink-soft)", textAlign: "right" }}>{w.meta}</div>
            </div>
          </button>
        ))}
      </div>

      <div style={{ marginTop: 48, paddingTop: 32, borderTop: "1px solid var(--border)", display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 32 }}>
        {[
          { k: "This week", v: "14", l: "briefs generated" },
          { k: "Noise filtered", v: "94.2%", l: "rejected signal" },
          { k: "Signal rate", v: "0.7/hr", l: "your lens · active" },
          { k: "Avg. time saved", v: "3.2h", l: "per brief" },
        ].map((s) => (
          <div key={s.k}>
            <Kicker>{s.k}</Kicker>
            <div className="display tnum" style={{ fontSize: 36, fontWeight: 400, marginTop: 4, color: "var(--ink)" }}>{s.v}</div>
            <div style={{ fontSize: 13, color: "var(--ink-muted)", marginTop: 4 }}>{s.l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ───────────────────────── 2. Intake Form ─────────────────────────
function IntelligenceIntake({ onSubmit, onBack }) {
  const [account, setAccount] = React.useState("Anthropic");
  const [site, setSite] = React.useState("anthropic.com");
  const [goal, setGoal] = React.useState("Explore partnership for enterprise signal data");
  const [type, setType] = React.useState("partner");
  const [attendees, setAttendees] = React.useState(["Sarah Chen", "Marcus Rivera"]);
  const [advanced, setAdvanced] = React.useState(true);

  const TYPES = [
    { id: "customer", label: "Customer" }, { id: "prospect", label: "Prospect" },
    { id: "partner", label: "Partner" }, { id: "investor", label: "Investor" },
    { id: "candidate", label: "Candidate" }, { id: "board", label: "Board" },
  ];

  const field = (label, hint, node) => (
    <div style={{ marginBottom: 28 }}>
      <label style={{ display: "block", fontSize: 13, fontWeight: 500, color: "var(--ink)", marginBottom: 4 }}>{label}</label>
      {hint && <div style={{ fontSize: 12, color: "var(--ink-muted)", marginBottom: 10 }}>{hint}</div>}
      {node}
    </div>
  );

  const input = (val, set, ph, type = "text") => (
    <input value={val} onChange={(e) => set(e.target.value)} placeholder={ph} type={type} style={{
      width: "100%", background: "var(--bg-elev)", border: "1px solid var(--border)",
      borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14, outline: "none",
    }} />
  );

  return (
    <div style={{ maxWidth: 680, margin: "0 auto", padding: "48px 48px 64px" }}>
      <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--ink-muted)", fontSize: 13, marginBottom: 24 }}>
        <I.arrowR size={14} style={{ transform: "rotate(180deg)" }} /> Back to workflows
      </button>
      <Kicker color="var(--amber)">01 · Intake · Meeting Prep</Kicker>
      <h1 className="display" style={{ fontSize: 44, fontWeight: 400, marginTop: 10, lineHeight: 1.1 }}>
        Tell the engine what you're walking into.
      </h1>

      <div style={{ marginTop: 40 }}>
        {field("Who are you meeting?", "Company or person. We'll pull public profile, news, and people.", input(account, setAccount, "Company or person"))}
        {field("What's your goal?", "This shapes what gets prioritized. Be specific.", (
          <textarea value={goal} onChange={(e) => setGoal(e.target.value)} rows={2} style={{
            width: "100%", background: "var(--bg-elev)", border: "1px solid var(--border)",
            borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14, outline: "none", resize: "none", fontFamily: "inherit",
          }} />
        ))}
        {field("Meeting type", "Adjusts the analysis lens.", (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {TYPES.map((t) => (
              <button key={t.id} onClick={() => setType(t.id)} style={{
                padding: "8px 14px", fontSize: 13, borderRadius: 999,
                background: type === t.id ? "var(--ink)" : "var(--surface)",
                color: type === t.id ? "var(--bg)" : "var(--ink-dim)",
                border: `1px solid ${type === t.id ? "var(--ink)" : "var(--border)"}`,
              }}>{t.label}</button>
            ))}
          </div>
        ))}
        {field("Website", "Optional. We scrape recent content directly.", input(site, setSite, "https://..."))}
        {field("Attendees", "Up to 5. We search LinkedIn + public profiles.", (
          <div>
            <div style={{ display: "flex", gap: 8, marginBottom: attendees.length ? 12 : 0 }}>
              <input placeholder="Name, then Enter" style={{
                flex: 1, background: "var(--bg-elev)", border: "1px solid var(--border)",
                borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14, outline: "none",
              }} />
              <Btn variant="solid" icon={<I.plus size={14} />}>Add</Btn>
            </div>
            {attendees.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {attendees.map((a) => (
                  <span key={a} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", borderRadius: 999, background: "var(--amber-soft)", color: "var(--amber)", fontSize: 12 }}>
                    {a} <I.x size={11} />
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}

        <button onClick={() => setAdvanced(!advanced)} style={{ color: "var(--ink-muted)", fontSize: 13, marginBottom: 24 }}>
          {advanced ? "− Less options" : "+ More options"}
        </button>
        {advanced && (
          <div style={{ padding: 20, background: "var(--surface)", borderRadius: 10, border: "1px solid var(--border)", marginBottom: 28 }}>
            {field("Relationship stage", null, (
              <div style={{ display: "flex", gap: 6 }}>
                {["Cold", "Warm intro", "Existing", "Re-engage"].map(s => (
                  <button key={s} style={{ padding: "6px 12px", fontSize: 12, borderRadius: 6, background: s === "Warm intro" ? "var(--surface-2)" : "transparent", border: "1px solid var(--border)", color: "var(--ink-dim)" }}>{s}</button>
                ))}
              </div>
            ))}
            {field("What you're selling / proposing", null, input("Proprietary signal data — ranked by consequence, API-delivered", () => {}, ""))}
            {field("Desired next step", null, input("Technical discovery with their engineering lead in 10 days", () => {}, ""))}
          </div>
        )}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12 }}>
        <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>Estimated: ~1m 45s · 8–12 sources</div>
        <Btn variant="amber" size="lg" icon={<I.bolt size={15} />} onClick={onSubmit}>Refine intent →</Btn>
      </div>
    </div>
  );
}

// ───────────────────────── 3. Refined Intent ─────────────────────────
function IntelligenceRefined({ onRun, onBack }) {
  return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: "64px 48px" }}>
      <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--ink-muted)", fontSize: 13, marginBottom: 24 }}>
        <I.arrowR size={14} style={{ transform: "rotate(180deg)" }} /> Edit inputs
      </button>
      <Kicker color="var(--amber)">02 · Refined intent</Kicker>
      <h1 className="display" style={{ fontSize: 40, fontWeight: 400, marginTop: 10, lineHeight: 1.1 }}>
        This is the brief the engine will run. Edit if you want.
      </h1>
      <p style={{ color: "var(--ink-muted)", marginTop: 12, fontSize: 14, maxWidth: 520 }}>
        We rewrote your raw input into a sharper internal brief. Research quality depends heavily on this.
      </p>

      <Card pad={0} style={{ marginTop: 32, overflow: "hidden" }}>
        <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <I.sparkle size={14} stroke="var(--amber)" />
            <span className="mono" style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-dim)" }}>System brief</span>
          </div>
          <button style={{ fontSize: 12, color: "var(--ink-muted)", display: "inline-flex", alignItems: "center", gap: 6 }}>
            <I.pen size={12} /> Edit
          </button>
        </div>
        <div style={{ padding: "28px 28px 32px", fontSize: 17, lineHeight: 1.55, color: "var(--ink)", fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: "-0.01em" }}>
          {MEETING_BRIEF.refined}
        </div>
      </Card>

      <div style={{ marginTop: 28, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
        {[
          { k: "Lens", v: "Partner · Founder" },
          { k: "Depth", v: "Standard · 8–12 sources" },
          { k: "Evidence buckets", v: "6 planned" },
        ].map((m) => (
          <div key={m.k} style={{ padding: "14px 16px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 10 }}>
            <Kicker>{m.k}</Kicker>
            <div style={{ fontSize: 13, color: "var(--ink)", marginTop: 4 }}>{m.v}</div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 32 }}>
        <Kicker>Evidence plan</Kicker>
        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--border)", border: "1px solid var(--border)", borderRadius: 10, overflow: "hidden" }}>
          {[
            ["Account snapshot", "anthropic.com, wiki, crunchbase"],
            ["Recent announcements", "90d news + launches"],
            ["Leadership & attendees", "LinkedIn, podcasts, interviews"],
            ["Hiring signals", "careers page, job boards"],
            ["Competitive context", "OpenAI, Google DeepMind"],
            ["Analyst coverage", "Bain, Stratechery, FT"],
          ].map(([k, v], i) => (
            <div key={i} style={{ background: "var(--bg-elev)", padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 13, color: "var(--ink)" }}>{k}</span>
              <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 36 }}>
        <Btn variant="amber" size="lg" icon={<I.bolt size={15} />} onClick={onRun}>Run the brief</Btn>
      </div>
    </div>
  );
}

// ───────────────────────── 4. Activity Rail (streaming) ─────────────────────────
function IntelligenceActivity({ onComplete }) {
  const [step, setStep] = React.useState(2);
  React.useEffect(() => {
    const t = setInterval(() => setStep((s) => Math.min(s + 1, 5)), 1400);
    return () => clearInterval(t);
  }, []);

  const steps = [
    { id: "resolve", label: "Resolving entity", sub: "Anthropic · anthropic.com · verified" },
    { id: "gather", label: "Gathering evidence", sub: "23 queries dispatched · 6 evidence buckets" },
    { id: "rank",    label: "Ranking evidence", sub: "72 sources → 18 kept · authority ≥ 70" },
    { id: "synth",   label: "Synthesizing findings", sub: "Separating facts from inference" },
    { id: "assemble", label: "Assembling brief", sub: "Meeting Prep layout · personalizing to lens" },
  ];

  const discoveries = [
    { kind: "fact", text: "Anthropic posted 14 enterprise roles in the last 30 days" },
    { kind: "source", text: "Block engineering blog — Claude for Work case study" },
    { kind: "person", text: "Sarah Chen joined Anthropic 6 weeks ago from Stripe" },
    { kind: "fact", text: "Dario: signal quality is 'the last mile' bottleneck" },
    { kind: "source", text: "Bain enterprise AI report Q1 2026" },
  ];

  React.useEffect(() => {
    if (step >= 5) {
      const t = setTimeout(() => onComplete?.(), 1200);
      return () => clearTimeout(t);
    }
  }, [step, onComplete]);

  return (
    <div style={{ maxWidth: 780, margin: "0 auto", padding: "80px 48px" }}>
      <Kicker color="var(--amber)">03 · Live · streaming</Kicker>
      <h1 className="display" style={{ fontSize: 36, fontWeight: 400, marginTop: 10, lineHeight: 1.1 }}>
        Reading the room. Filtering the noise.
      </h1>

      <Card pad={0} style={{ marginTop: 32 }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Dot color="var(--amber)" pulse size={8} />
            <span className="mono" style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-dim)" }}>Research progress</span>
          </div>
          <span className="mono tnum" style={{ fontSize: 11, color: "var(--ink-muted)" }}>00:{Math.min(step * 20 + 5, 107).toString().padStart(2, "0")}</span>
        </div>
        <div style={{ padding: "20px 24px" }}>
          {steps.map((s, i) => {
            const state = i < step ? "done" : i === step ? "active" : "pending";
            return (
              <div key={s.id} style={{ display: "flex", gap: 16, paddingBottom: 18, position: "relative" }}>
                {i < steps.length - 1 && <div style={{ position: "absolute", left: 11, top: 24, width: 1, height: "calc(100% - 18px)", background: i < step ? "var(--amber-dim)" : "var(--border)" }} />}
                <div style={{ width: 22, height: 22, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
                  background: state === "done" ? "var(--green)" : state === "active" ? "var(--amber)" : "var(--surface)",
                  border: state === "pending" ? "1px solid var(--border-strong)" : "none", zIndex: 1,
                }}>
                  {state === "done" && <I.check size={12} stroke="var(--bg)" sw={2.5} />}
                  {state === "active" && <Dot size={6} color="var(--bg)" />}
                </div>
                <div style={{ flex: 1, paddingTop: 2 }}>
                  <div style={{ fontSize: 14, fontWeight: 500, color: state === "pending" ? "var(--ink-muted)" : "var(--ink)" }}>{s.label}</div>
                  {(state === "done" || state === "active") && <div style={{ fontSize: 12, color: "var(--ink-muted)", marginTop: 3 }}>{s.sub}</div>}
                </div>
                {state === "active" && <span className="mono" style={{ fontSize: 10, color: "var(--amber)", letterSpacing: "0.08em" }}>RUNNING</span>}
              </div>
            );
          })}
        </div>

        <div style={{ padding: "16px 24px", borderTop: "1px solid var(--border)", background: "var(--surface)" }}>
          <Kicker>Discoveries · {Math.min(step + 1, discoveries.length)}</Kicker>
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8, maxHeight: 160, overflow: "hidden" }}>
            {discoveries.slice(0, Math.min(step + 1, discoveries.length)).map((d, i) => (
              <div key={i} className="rise" style={{ display: "flex", gap: 10, alignItems: "baseline", fontSize: 12 }}>
                <Pill color={d.kind === "fact" ? "var(--green)" : d.kind === "person" ? "var(--violet)" : "var(--ink-muted)"}>{d.kind}</Pill>
                <span style={{ color: "var(--ink-dim)" }}>{d.text}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { IntelligencePicker, IntelligenceIntake, IntelligenceRefined, IntelligenceActivity });
