/* App screens: Feed, Signal detail, Ask AI, Onboarding, Profile, History, Share, Marketing, Auth */

// ───────────────────────── Feed ─────────────────────────
function Feed() {
  const [active, setActive] = React.useState("all");
  const [selected, setSelected] = React.useState(null);
  const filters = [
    { id: "all", label: "All signals", count: 47 },
    { id: "hot", label: "Hot", count: 6 },
    { id: "competitive", label: "Competitive", count: 12 },
    { id: "opportunity", label: "Opportunity", count: 8 },
    { id: "risk", label: "Risk", count: 4 },
    { id: "strategic", label: "Strategic", count: 17 },
  ];
  const trajColor = (t) => ({
    ESCALATING: "var(--red)", EMERGING: "var(--amber)",
    DEVELOPING: "var(--green)", STABLE: "var(--ink-dim)", FADING: "var(--ink-muted)"
  }[t]);

  return (
    <div>
      {/* Ticker */}
      <div style={{ height: 28, background: "var(--bg-elev)", borderBottom: "1px solid var(--border)", overflow: "hidden" }}>
        <div className="marquee-track mono" style={{ fontSize: 11, letterSpacing: "0.04em", whiteSpace: "nowrap", lineHeight: "28px" }}>
          {[...TICKER, ...TICKER].map((t, i) => (
            <span key={i} style={{ marginRight: 36 }}>
              <span style={{ color: "var(--ink-soft)" }}>{t.label}</span>{" "}
              <span style={{ color: t.kind === "up" ? "var(--green)" : t.kind === "down" ? "var(--red)" : "var(--amber)" }}>{t.value}</span>{" "}
              <span style={{ color: "var(--ink-muted)" }}>{t.note}</span>
              <span style={{ color: "var(--border)", margin: "0 18px" }}>·</span>
            </span>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", minHeight: "calc(100% - 28px)" }}>
        {/* Filter rail */}
        <div style={{ borderRight: "1px solid var(--border)", padding: "28px 20px", background: "var(--bg-elev)" }}>
          <Kicker>Your lens</Kicker>
          <div style={{ marginTop: 10, padding: "12px 14px", background: "var(--surface)", borderRadius: 8, border: "1px solid var(--border)" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Founder · GTM · AI infra</div>
            <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 6 }}>0.7 signals/hr · 94% filtered</div>
          </div>
          <div style={{ marginTop: 24 }}>
            <Kicker>Filters</Kicker>
            <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 2 }}>
              {filters.map(f => (
                <button key={f.id} onClick={() => setActive(f.id)} style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "8px 10px", borderRadius: 6, fontSize: 13,
                  background: active === f.id ? "var(--surface)" : "transparent",
                  color: active === f.id ? "var(--ink)" : "var(--ink-dim)",
                  textAlign: "left",
                }}>
                  <span>{f.label}</span>
                  <span className="mono tnum" style={{ fontSize: 11, color: "var(--ink-muted)" }}>{f.count}</span>
                </button>
              ))}
            </div>
          </div>
          <div style={{ marginTop: 24 }}>
            <Kicker>Watching</Kicker>
            <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 4 }}>
              {["Anthropic", "OpenAI", "Cursor", "Stripe", "LangChain"].map(w => (
                <div key={w} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 10px", fontSize: 13, color: "var(--ink-dim)" }}>
                  <span>{w}</span>
                  <Dot color="var(--green)" size={5} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Feed */}
        <div style={{ padding: "32px 44px 48px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 28 }}>
            <div>
              <Kicker>Today · April 18, 2026</Kicker>
              <h1 className="display" style={{ fontSize: 38, fontWeight: 400, marginTop: 6, letterSpacing: "-0.02em" }}>
                6 things moved that matter to you.
              </h1>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="ghost" size="sm" icon={<I.sliders size={13} />}>Tune lens</Btn>
              <Btn variant="ghost" size="sm" icon={<I.history size={13} />}>Timeline</Btn>
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {FEED_SIGNALS.map((s, i) => (
              <div key={s.id} onClick={() => setSelected(s)} className="hoverable" style={{
                background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 12,
                padding: "22px 26px", display: "grid", gridTemplateColumns: "60px 1fr 140px", gap: 20, alignItems: "start",
                transition: "border-color 0.15s ease, transform 0.15s ease",
              }}
              onMouseEnter={(e) => e.currentTarget.style.borderColor = "var(--border-strong)"}
              onMouseLeave={(e) => e.currentTarget.style.borderColor = "var(--border)"}>
                <div style={{ textAlign: "center", paddingTop: 4 }}>
                  <div className="display tnum" style={{ fontSize: 30, fontWeight: 400, color: trajColor(s.trajectory), letterSpacing: "-0.02em" }}>{s.score}</div>
                  <div className="mono" style={{ fontSize: 9, color: "var(--ink-muted)", letterSpacing: "0.1em", marginTop: 2 }}>RELEVANCE</div>
                </div>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                    <Pill color={trajColor(s.trajectory)} bg={`color-mix(in oklch, ${trajColor(s.trajectory)}, transparent 86%)`} border={trajColor(s.trajectory)}>{s.trajectory}</Pill>
                    {s.hot && <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)"><Dot size={5} color="var(--amber)" pulse /> Hot</Pill>}
                    {s.consequence.map(c => <Pill key={c}>{c}</Pill>)}
                  </div>
                  <h3 className="display" style={{ fontSize: 20, fontWeight: 500, lineHeight: 1.3, letterSpacing: "-0.01em" }}>{s.headline}</h3>
                  <p style={{ fontSize: 14, color: "var(--ink-dim)", lineHeight: 1.55, marginTop: 10, maxWidth: 640 }}>{s.synthesis}</p>
                  <div style={{ display: "flex", gap: 14, marginTop: 12, alignItems: "center", fontSize: 11, color: "var(--ink-muted)" }}>
                    <span className="mono">{s.date}</span>
                    <span style={{ color: "var(--border-strong)" }}>·</span>
                    <span className="mono">{s.sources} sources</span>
                    <span style={{ color: "var(--border-strong)" }}>·</span>
                    <div style={{ display: "flex", gap: 4 }}>
                      {s.domains.slice(0, 3).map(d => <span key={d} className="mono" style={{ padding: "2px 6px", background: "var(--surface)", borderRadius: 3, fontSize: 10 }}>{d}</span>)}
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
                  <Btn variant="ghost" size="sm" icon={<I.ask size={12} />}>Ask</Btn>
                  <Btn variant="ghost" size="sm" icon={<I.arrowR size={12} />}>Open</Btn>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Signal detail ─────────────────────────
function SignalDetail() {
  const s = FEED_SIGNALS[0];
  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "40px 40px 64px" }}>
      <button style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--ink-muted)", fontSize: 13, marginBottom: 20 }}>
        <I.arrowR size={13} style={{ transform: "rotate(180deg)" }} /> Back to feed
      </button>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <Pill color="var(--red)" bg="oklch(0.7 0.17 25 / 0.12)" border="var(--red)">{s.trajectory}</Pill>
        <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)"><Dot size={5} color="var(--amber)" pulse /> Hot</Pill>
        <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>SIG-0418-ANTHR · {s.date}</span>
      </div>
      <h1 className="display" style={{ fontSize: 44, fontWeight: 400, lineHeight: 1.1, letterSpacing: "-0.02em" }}>{s.headline}</h1>
      <div style={{ marginTop: 20, padding: "18px 22px", background: "var(--amber-soft)", borderLeft: "3px solid var(--amber)", borderRadius: 8 }}>
        <Kicker color="var(--amber)">Synthesis · why it matters to you</Kicker>
        <div style={{ fontSize: 16, color: "var(--ink)", marginTop: 8, lineHeight: 1.5 }}>{s.synthesis}</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginTop: 28 }}>
        {[["Relevance", s.score, "var(--amber)"], ["Sources", s.sources, "var(--green)"], ["Consequence", s.consequence.join(" · "), "var(--violet)"]].map(([k, v, c]) => (
          <Card key={k}>
            <Kicker>{k}</Kicker>
            <div className="display" style={{ fontSize: 26, fontWeight: 400, color: c, marginTop: 6 }}>{v}</div>
          </Card>
        ))}
      </div>

      <section style={{ marginTop: 44 }}>
        <Kicker>Trajectory · last 7 days</Kicker>
        <Card style={{ marginTop: 10, padding: 22 }}>
          <svg viewBox="0 0 600 120" style={{ width: "100%", height: 120 }}>
            <defs>
              <linearGradient id="tg" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="var(--amber)" stopOpacity="0.4"/>
                <stop offset="100%" stopColor="var(--amber)" stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d="M0,100 L60,85 L120,90 L180,70 L240,65 L300,55 L360,40 L420,30 L480,25 L540,15 L600,8" fill="none" stroke="var(--amber)" strokeWidth="2"/>
            <path d="M0,100 L60,85 L120,90 L180,70 L240,65 L300,55 L360,40 L420,30 L480,25 L540,15 L600,8 L600,120 L0,120 Z" fill="url(#tg)"/>
            {[0,100,200,300,400,500,600].map(x => <line key={x} x1={x} x2={x} y1="0" y2="120" stroke="var(--border)" strokeWidth="0.5"/>)}
          </svg>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }} className="mono">
            {["Apr 11","12","13","14","15","16","17","18"].map(d => <span key={d} style={{ fontSize: 10, color: "var(--ink-muted)" }}>{d}</span>)}
          </div>
        </Card>
      </section>

      <section style={{ marginTop: 44 }}>
        <Kicker>Source map · {s.sources}</Kicker>
        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {MEETING_BRIEF.sources.slice(0, 6).map(src => (
            <div key={src.id} style={{ padding: "14px 16px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 8, display: "flex", gap: 12, alignItems: "center" }}>
              <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-muted)", minWidth: 18 }}>[{src.id}]</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: "var(--ink)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{src.title}</div>
                <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 2 }}>{src.domain} · {src.date}</div>
              </div>
              <Pill color={src.kind === "official" ? "var(--green)" : src.kind === "analyst" ? "var(--violet)" : "var(--amber)"}>{src.kind}</Pill>
            </div>
          ))}
        </div>
      </section>

      <section style={{ marginTop: 44 }}>
        <Kicker>Actions</Kicker>
        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
          {[
            ["Generate Meeting Prep", "for Anthropic", I.briefcase],
            ["Generate Competitive Analysis", "vs OpenAI", I.swords],
            ["Ask AI", "anything about this", I.ask],
          ].map(([t, sub, Ic]) => (
            <button key={t} style={{ padding: "18px 20px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 10, textAlign: "left" }}>
              <Ic size={18} stroke="var(--amber)" />
              <div style={{ fontSize: 14, fontWeight: 500, marginTop: 12 }}>{t}</div>
              <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 4 }}>{sub}</div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

// ───────────────────────── Ask AI ─────────────────────────
function AskAI() {
  const [q, setQ] = React.useState("");
  const msgs = [
    { role: "user", text: "What's Anthropic's enterprise GTM motion actually look like in practice?" },
    { role: "ai", text: "Anthropic's enterprise motion has three visible layers. First, a direct sales team anchored by Marcus Rivera (ex-Databricks) focused on Fortune 500s — 14 of the 30 new hires are account-facing. Second, a partner program being built by Sarah Chen (6 weeks in role from Stripe) — curated, co-sell oriented, not self-serve. Third, Claude for Work as the distribution surface itself, with embedded retrieval and soon agents. The pattern matches what Stripe did 2019-2021: land infra, earn trust, then layer partners onto a known install base.", sources: [1,2,5,6,7] },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", height: "100%" }}>
      <div style={{ borderRight: "1px solid var(--border)", padding: "24px 18px", background: "var(--bg-elev)" }}>
        <Btn variant="amber" icon={<I.plus size={13} />} style={{ width: "100%", justifyContent: "center" }}>New chat</Btn>
        <Kicker style={{ marginTop: 24 }}>Recent</Kicker>
        <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 2 }}>
          {["Anthropic GTM motion", "Cursor vs Copilot bull case", "Agent payments landscape", "EU AI Act Article 6", "LangChain exit options"].map((t, i) => (
            <button key={i} style={{ padding: "8px 10px", fontSize: 13, color: i === 0 ? "var(--ink)" : "var(--ink-dim)", textAlign: "left", borderRadius: 6, background: i === 0 ? "var(--surface)" : "transparent" }}>
              {t}
            </button>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ flex: 1, overflow: "auto", padding: "40px 48px" }}>
          <div style={{ maxWidth: 760, margin: "0 auto" }}>
            {msgs.map((m, i) => (
              <div key={i} style={{ marginBottom: 32 }}>
                {m.role === "user" ? (
                  <div style={{ display: "flex", gap: 14 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: "var(--surface-2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "var(--ink)", fontWeight: 600 }}>A</div>
                    <div style={{ flex: 1, paddingTop: 4 }}>
                      <div style={{ fontSize: 16, color: "var(--ink)", lineHeight: 1.5 }}>{m.text}</div>
                    </div>
                  </div>
                ) : (
                  <div style={{ display: "flex", gap: 14 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: "var(--amber-soft)", border: "1px solid var(--amber)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <I.sparkle size={13} stroke="var(--amber)" />
                    </div>
                    <div style={{ flex: 1 }}>
                      <Kicker color="var(--amber)">Relevant · grounded in 5 sources</Kicker>
                      <div style={{ fontSize: 16, lineHeight: 1.6, color: "var(--ink)", marginTop: 8 }}>{m.text}</div>
                      <div style={{ marginTop: 16, display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {m.sources.map(sid => {
                          const src = MEETING_BRIEF.sources.find(x => x.id === sid);
                          return <span key={sid} className="mono" style={{ padding: "4px 8px", borderRadius: 4, fontSize: 11, background: "var(--surface)", border: "1px solid var(--border)", color: "var(--ink-dim)" }}>[{sid}] {src.domain}</span>;
                        })}
                      </div>
                      <div style={{ marginTop: 14, display: "flex", gap: 10 }}>
                        <Btn variant="ghost" size="sm" icon={<I.briefcase size={12} />}>Turn into Meeting Prep</Btn>
                        <Btn variant="ghost" size="sm" icon={<I.copy size={12} />}>Copy</Btn>
                        <Btn variant="ghost" size="sm" icon={<I.share size={12} />}>Share</Btn>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
              {["How does this compare to OpenAI's motion?", "What should I expect in 90 days?", "Give me 3 objections and responses."].map(s => (
                <button key={s} style={{ padding: "8px 14px", fontSize: 13, background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 999, color: "var(--ink-dim)" }}>{s}</button>
              ))}
            </div>
          </div>
        </div>
        <div style={{ padding: "20px 48px 28px", borderTop: "1px solid var(--border)", background: "var(--bg-elev)" }}>
          <div style={{ maxWidth: 760, margin: "0 auto", display: "flex", gap: 10, padding: "12px 14px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12 }}>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask anything. Grounded in your lens." style={{ flex: 1, background: "transparent", border: "none", outline: "none", fontSize: 15, color: "var(--ink)" }} />
            <Btn variant="amber" size="sm" icon={<I.arrowR size={12} />}>Send</Btn>
          </div>
          <div className="mono" style={{ maxWidth: 760, margin: "8px auto 0", fontSize: 10, color: "var(--ink-muted)", display: "flex", gap: 16 }}>
            <span>⏎ Send</span><span>⇧⏎ New line</span><span>/ Slash commands</span><span>@ Mention entity</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Onboarding ─────────────────────────
function Onboarding() {
  const [step, setStep] = React.useState(2);
  const steps = ["Who you are", "Your lens", "What you follow", "Cadence"];
  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "56px 48px" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 36 }}>
        {steps.map((s, i) => (
          <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= step ? "var(--amber)" : "var(--border)" }} />
        ))}
      </div>
      <Kicker color="var(--amber)">Step {step + 1} of 4 · Lens</Kicker>
      <h1 className="display" style={{ fontSize: 40, fontWeight: 400, marginTop: 10, lineHeight: 1.1 }}>
        What's the lens through which you read the world?
      </h1>
      <p style={{ color: "var(--ink-muted)", marginTop: 12, fontSize: 15, maxWidth: 520, lineHeight: 1.5 }}>
        This is the filter the engine uses. Specific beats broad. Every signal gets ranked against it.
      </p>

      <Card style={{ marginTop: 32, padding: 28 }}>
        <Kicker>Your role</Kicker>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>
          {["Founder", "Operator", "Investor", "Product", "Sales", "Engineer", "Analyst"].map((r, i) => (
            <button key={r} style={{ padding: "8px 14px", fontSize: 13, borderRadius: 999, background: i === 0 ? "var(--ink)" : "var(--surface)", color: i === 0 ? "var(--bg)" : "var(--ink-dim)", border: `1px solid ${i === 0 ? "var(--ink)" : "var(--border)"}` }}>{r}</button>
          ))}
        </div>
        <div style={{ marginTop: 24 }}>
          <Kicker>Market you operate in</Kicker>
          <input defaultValue="AI infrastructure · signal data · enterprise GTM" style={{ width: "100%", marginTop: 10, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14 }} />
        </div>
        <div style={{ marginTop: 24 }}>
          <Kicker>What decisions are you making right now?</Kicker>
          <textarea rows={3} defaultValue="Prioritizing partnership vs direct GTM. Choosing foundation model bets. Quarterly roadmap tradeoffs." style={{ width: "100%", marginTop: 10, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14, fontFamily: "inherit", resize: "none" }} />
        </div>
      </Card>

      <div style={{ marginTop: 20, padding: "14px 18px", background: "var(--amber-soft)", borderRadius: 8, border: "1px solid color-mix(in oklch, var(--amber), transparent 70%)", display: "flex", gap: 12 }}>
        <I.sparkle size={16} stroke="var(--amber)" />
        <div style={{ fontSize: 13, color: "var(--ink-dim)", lineHeight: 1.5 }}>
          <strong style={{ color: "var(--ink)" }}>Preview:</strong> With this lens, ~12 signals/day will rank above your threshold. You can tune this anytime.
        </div>
      </div>

      <div style={{ marginTop: 32, display: "flex", justifyContent: "space-between" }}>
        <Btn variant="ghost" onClick={() => setStep(Math.max(0, step - 1))}>Back</Btn>
        <Btn variant="amber" size="lg" icon={<I.arrowR size={14} />} onClick={() => setStep(Math.min(3, step + 1))}>Continue</Btn>
      </div>
    </div>
  );
}

// ───────────────────────── Profile / Settings ─────────────────────────
function Profile() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", height: "100%" }}>
      <div style={{ borderRight: "1px solid var(--border)", padding: "32px 20px", background: "var(--bg-elev)" }}>
        <Kicker>Settings</Kicker>
        {[{t:"Profile", active: true},{t:"Lens & filters"},{t:"Notifications"},{t:"Integrations"},{t:"Team"},{t:"Billing"},{t:"API"}].map(s => (
          <button key={s.t} style={{ display: "block", width: "100%", padding: "8px 10px", marginTop: 4, fontSize: 13, color: s.active ? "var(--ink)" : "var(--ink-dim)", textAlign: "left", background: s.active ? "var(--surface)" : "transparent", borderRadius: 6 }}>{s.t}</button>
        ))}
      </div>
      <div style={{ padding: "40px 48px", maxWidth: 820 }}>
        <Kicker color="var(--amber)">Your profile</Kicker>
        <h1 className="display" style={{ fontSize: 36, fontWeight: 400, marginTop: 6, letterSpacing: "-0.02em" }}>Ayaan Shah</h1>
        <div style={{ display: "flex", alignItems: "center", gap: 20, marginTop: 28, paddingBottom: 28, borderBottom: "1px solid var(--border)" }}>
          <div style={{ width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(135deg, var(--amber), var(--green))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 500, color: "var(--bg)" }}>AS</div>
          <div>
            <div style={{ fontSize: 15, color: "var(--ink)" }}>Founder · Relevant</div>
            <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", marginTop: 4 }}>ayaan@relevant.ai · Member since Feb 2026</div>
          </div>
          <Btn variant="ghost" size="sm" style={{ marginLeft: "auto" }}>Edit</Btn>
        </div>

        <section style={{ marginTop: 36 }}>
          <Kicker>Usage · this month</Kicker>
          <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12 }}>
            {[["Briefs", "23 / ∞"],["Signals ranked", "1,247"],["Sources processed", "8,418"],["Time saved", "74h"]].map(([k, v]) => (
              <Card key={k}>
                <Kicker>{k}</Kicker>
                <div className="display tnum" style={{ fontSize: 28, fontWeight: 400, marginTop: 4 }}>{v}</div>
              </Card>
            ))}
          </div>
        </section>

        <section style={{ marginTop: 36 }}>
          <Kicker>Lens</Kicker>
          <Card style={{ marginTop: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 500 }}>Founder · GTM · AI infra</div>
                <div style={{ fontSize: 13, color: "var(--ink-dim)", marginTop: 8, lineHeight: 1.5 }}>
                  Prioritizing partnership vs direct GTM. Choosing foundation model bets. Quarterly roadmap tradeoffs.
                </div>
                <div style={{ marginTop: 14, display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {["Anthropic","OpenAI","Cursor","Stripe","LangChain","Bain","Stratechery"].map(t => (
                    <span key={t} className="mono" style={{ fontSize: 11, padding: "3px 9px", borderRadius: 999, background: "var(--surface)", color: "var(--ink-dim)", border: "1px solid var(--border)" }}>{t}</span>
                  ))}
                </div>
              </div>
              <Btn variant="ghost" size="sm" icon={<I.sliders size={12} />}>Tune</Btn>
            </div>
          </Card>
        </section>

        <section style={{ marginTop: 36 }}>
          <Kicker>Integrations</Kicker>
          <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[["Gmail", "Connected", true], ["Calendar", "Connected", true], ["Slack", "Disconnected", false], ["Notion", "Disconnected", false]].map(([name, status, ok]) => (
              <div key={name} style={{ padding: "14px 18px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{name}</div>
                  <div style={{ fontSize: 12, color: ok ? "var(--green)" : "var(--ink-muted)", marginTop: 2 }}><Dot size={5} color={ok ? "var(--green)" : "var(--ink-muted)"} /> {status}</div>
                </div>
                <Btn variant="ghost" size="sm">{ok ? "Manage" : "Connect"}</Btn>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

// ───────────────────────── History ─────────────────────────
function History() {
  const items = [
    { date: "Today", briefs: [
      { t: "Meeting prep · Anthropic", w: "meeting", time: "18:47", acc: "var(--amber)" },
      { t: "Competitive analysis · Cursor vs Copilot", w: "competitive", time: "14:22", acc: "var(--green)" },
    ]},
    { date: "Yesterday", briefs: [
      { t: "Business case · Launch weekend delivery", w: "business", time: "16:08", acc: "var(--amber)" },
      { t: "Meeting prep · Sequoia (pre-read)", w: "meeting", time: "09:41", acc: "var(--amber)" },
    ]},
    { date: "Earlier this week", briefs: [
      { t: "Market research · Agent payments infra", w: "market", time: "Apr 16 · 11:20", acc: "var(--green)" },
      { t: "Competitive analysis · Anthropic vs OpenAI", w: "competitive", time: "Apr 15 · 19:03", acc: "var(--green)" },
      { t: "Meeting prep · Stripe partnerships", w: "meeting", time: "Apr 15 · 08:30", acc: "var(--amber)" },
    ]},
  ];
  return (
    <div style={{ maxWidth: 920, margin: "0 auto", padding: "40px 48px 64px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 32 }}>
        <div>
          <Kicker>Intelligence history</Kicker>
          <h1 className="display" style={{ fontSize: 38, fontWeight: 400, marginTop: 6, letterSpacing: "-0.02em" }}>Your briefs.</h1>
          <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", marginTop: 8 }}>23 briefs this month · avg 2m 14s · 186 sources processed</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="ghost" size="sm" icon={<I.search size={13} />}>Search</Btn>
          <Btn variant="amber" size="sm" icon={<I.plus size={13} />}>New brief</Btn>
        </div>
      </div>
      {items.map(day => (
        <div key={day.date} style={{ marginBottom: 28 }}>
          <Kicker>{day.date}</Kicker>
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 1, background: "var(--border)", border: "1px solid var(--border)", borderRadius: 10, overflow: "hidden" }}>
            {day.briefs.map((b, i) => (
              <button key={i} className="hoverable" style={{ background: "var(--bg-elev)", padding: "16px 20px", display: "grid", gridTemplateColumns: "3px 1fr auto auto auto", gap: 16, alignItems: "center", textAlign: "left" }}>
                <div style={{ width: 3, height: 28, background: b.acc, borderRadius: 2 }} />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500, color: "var(--ink)" }}>{b.t}</div>
                  <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 4, letterSpacing: "0.04em" }}>{b.w.toUpperCase()} · 8 sources · personalized</div>
                </div>
                <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>{b.time}</span>
                <Btn variant="ghost" size="sm" icon={<I.eye size={12} />}>Open</Btn>
                <I.dotsV size={16} stroke="var(--ink-muted)" />
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ───────────────────────── Public Share ─────────────────────────
function SharePage() {
  const b = MEETING_BRIEF;
  return (
    <div style={{ background: "var(--bg)", minHeight: "100%" }}>
      <div style={{ borderBottom: "1px solid var(--border)", padding: "14px 40px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--bg-elev)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {I.logo(20)}
          <span className="mono" style={{ fontSize: 12, letterSpacing: "0.1em", color: "var(--ink)" }}>RELEVANT</span>
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", letterSpacing: "0.04em", marginLeft: 16 }}>shared brief · read-only</span>
        </div>
        <Btn variant="amber" size="sm">Get your own</Btn>
      </div>
      <div style={{ maxWidth: 760, margin: "0 auto", padding: "56px 40px 72px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
          <LogoChip name={b.account} color={b.snapshot.logoColor} size={36} />
          <div>
            <div className="display" style={{ fontSize: 24, fontWeight: 400 }}>{b.account}</div>
            <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 2 }}>Meeting prep · shared by Ayaan · Apr 18, 2026</div>
          </div>
        </div>
        <h1 className="display" style={{ fontSize: 40, fontWeight: 400, lineHeight: 1.1, letterSpacing: "-0.02em", marginTop: 16 }}>{b.bottomLine}</h1>
        <div style={{ marginTop: 28, padding: "20px 24px", background: "var(--amber-soft)", borderLeft: "3px solid var(--amber)", borderRadius: 8 }}>
          <Kicker color="var(--amber)">Why this matters</Kicker>
          <div style={{ fontSize: 15, color: "var(--ink)", marginTop: 8, lineHeight: 1.5 }}>{b.why}</div>
        </div>
        <section style={{ marginTop: 48 }}>
          <Kicker>Key talking points</Kicker>
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 12 }}>
            {b.talkingPoints.slice(0, 3).map((t, i) => (
              <div key={i} style={{ padding: "16px 20px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 15, color: "var(--ink)", lineHeight: 1.5 }}>{t.text}</div>
            ))}
          </div>
        </section>
        <div style={{ marginTop: 56, paddingTop: 28, borderTop: "1px solid var(--border)", textAlign: "center" }}>
          <div className="display" style={{ fontSize: 20, fontWeight: 400 }}>Want briefs this good for your meetings?</div>
          <Btn variant="amber" size="lg" style={{ marginTop: 16 }}>Try Relevant free</Btn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Feed, SignalDetail, AskAI, Onboarding, Profile, History, SharePage });
