/* Shared UI primitives, icons, data, and helpers for Relevant prototype */

// ───────────────────────── Icons (inline SVG, 1.5 stroke) ─────────────────────────
const Icon = ({ d, size = 16, fill = "none", stroke = "currentColor", sw = 1.5 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }} dangerouslySetInnerHTML={{ __html: d }} />
);

const I = {
  logo: (s = 20, c = "currentColor") => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M4 4h8a6 6 0 016 6 6 6 0 01-6 6h-4l7 4" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="17" cy="4.5" r="1.5" fill="var(--amber)"/>
    </svg>
  ),
  compass:   (p) => <Icon {...p} d='<circle cx="12" cy="12" r="9"/><path d="M15 9l-2 6-6 2 2-6z"/>' />,
  feed:      (p) => <Icon {...p} d='<path d="M4 5h16M4 12h16M4 19h10"/>' />,
  brain:     (p) => <Icon {...p} d='<path d="M9 4a3 3 0 00-3 3v1a3 3 0 00-2 3v1a3 3 0 002 3v1a3 3 0 003 3h0a3 3 0 003-3V4a0 0 0 00-3 0z"/><path d="M15 4a3 3 0 013 3v1a3 3 0 012 3v1a3 3 0 01-2 3v1a3 3 0 01-3 3h0a3 3 0 01-3-3V4a0 0 0 013 0z"/>' />,
  ask:       (p) => <Icon {...p} d='<path d="M21 12a8 8 0 01-11.6 7.1L4 20l1-5.4A8 8 0 1121 12z"/>' />,
  search:    (p) => <Icon {...p} d='<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>' />,
  share:     (p) => <Icon {...p} d='<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l7 4M15.4 6.5l-7 4"/>' />,
  user:      (p) => <Icon {...p} d='<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>' />,
  settings:  (p) => <Icon {...p} d='<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/>' />,
  arrowR:    (p) => <Icon {...p} d='<path d="M5 12h14M13 6l6 6-6 6"/>' />,
  arrowUp:   (p) => <Icon {...p} d='<path d="M12 19V5M6 11l6-6 6 6"/>' />,
  arrowDown: (p) => <Icon {...p} d='<path d="M12 5v14M6 13l6 6 6-6"/>' />,
  check:     (p) => <Icon {...p} d='<path d="M5 13l4 4L19 7"/>' />,
  x:         (p) => <Icon {...p} d='<path d="M6 6l12 12M6 18L18 6"/>' />,
  plus:      (p) => <Icon {...p} d='<path d="M12 5v14M5 12h14"/>' />,
  minus:     (p) => <Icon {...p} d='<path d="M5 12h14"/>' />,
  bolt:      (p) => <Icon {...p} d='<path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>' />,
  clock:     (p) => <Icon {...p} d='<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>' />,
  chevR:     (p) => <Icon {...p} d='<path d="M9 6l6 6-6 6"/>' />,
  chevD:     (p) => <Icon {...p} d='<path d="M6 9l6 6 6-6"/>' />,
  chevU:     (p) => <Icon {...p} d='<path d="M6 15l6-6 6 6"/>' />,
  dots:      (p) => <Icon {...p} d='<circle cx="5" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="19" cy="12" r="1.2" fill="currentColor"/>' />,
  dotsV:     (p) => <Icon {...p} d='<circle cx="12" cy="5" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/>' />,
  sparkle:   (p) => <Icon {...p} d='<path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8z"/>' />,
  target:    (p) => <Icon {...p} d='<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>' />,
  flame:     (p) => <Icon {...p} d='<path d="M12 2s4 5 4 9a4 4 0 11-8 0c0-2 2-4 4-9z"/><path d="M12 22a6 6 0 006-6c0-3-3-4-3-4s-1 2-3 2-3-2-3-2-3 1-3 4a6 6 0 006 6z"/>' />,
  sliders:   (p) => <Icon {...p} d='<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="currentColor" stroke="var(--bg)"/><circle cx="16" cy="12" r="2" fill="currentColor" stroke="var(--bg)"/><circle cx="10" cy="18" r="2" fill="currentColor" stroke="var(--bg)"/>' />,
  download:  (p) => <Icon {...p} d='<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>' />,
  link:      (p) => <Icon {...p} d='<path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l1-1"/>' />,
  copy:      (p) => <Icon {...p} d='<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>' />,
  warning:   (p) => <Icon {...p} d='<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.5"/>' />,
  up:        (p) => <Icon {...p} d='<path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/>' />,
  down:      (p) => <Icon {...p} d='<path d="M3 7l6 6 4-4 8 8"/><path d="M14 17h7v-7"/>' />,
  building:  (p) => <Icon {...p} d='<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2M10 21v-4h4v4"/>' />,
  users:     (p) => <Icon {...p} d='<circle cx="9" cy="8" r="3.5"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/><circle cx="17" cy="8" r="3"/><path d="M15 15c3 0 6 2 6 5"/>' />,
  swords:    (p) => <Icon {...p} d='<path d="M3 3l8 8M5 3h3v3M3 5v3M21 21l-8-8M21 19v-3M16 21h3"/><path d="M9 13l-3 3v3h3l3-3"/>' />,
  book:      (p) => <Icon {...p} d='<path d="M4 4h8a4 4 0 014 4v12a4 4 0 00-4-4H4V4z"/><path d="M20 4h-4a4 4 0 00-4 4v12"/>' />,
  history:   (p) => <Icon {...p} d='<path d="M3 12a9 9 0 109-9 9 9 0 00-7 3"/><path d="M3 3v5h5M12 7v5l4 2"/>' />,
  eye:       (p) => <Icon {...p} d='<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>' />,
  mail:      (p) => <Icon {...p} d='<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>' />,
  briefcase: (p) => <Icon {...p} d='<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 012-2h4a2 2 0 012 2v2"/>' />,
  pen:       (p) => <Icon {...p} d='<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4z"/>' />,
};

// ───────────────────────── Fixture data ─────────────────────────

const MEETING_BRIEF = {
  account: "Anthropic",
  website: "anthropic.com",
  goal: "Understand their GTM + explore partnership for enterprise signal data",
  type: "Partner / Enterprise",
  refined: "Assess Anthropic's current enterprise go-to-market motion, evaluate openness to a signal-data partnership, and prepare specific proof-points and objection responses for a 30-minute intro with their partnerships lead.",
  confidence: "High",
  bottomLine: "Anthropic is leaning hard into enterprise; three recent hires and a Fortune 500 push signal the partnerships team is scaling. Lead with proprietary signal data, not model claims.",
  why: "You're walking into a room where they are explicitly buying distribution, not technology. Your lens — ranked signal data — sits upstream of their Claude-for-Work play.",
  snapshot: {
    industry: "AI research / foundation models",
    hq: "San Francisco, CA",
    size: "~950 employees",
    funding: "Series E · $8.0B (Mar 2026)",
    ceo: "Dario Amodei",
    recent: "Launched Claude for Work Enterprise tier, Apr 2026",
    logoColor: "oklch(0.72 0.14 62)",
  },
  people: [
    { name: "Sarah Chen", title: "Head of Partnerships", background: "Ex-Stripe, Ex-Google Cloud. Scaled Stripe's fintech partner program from 12 to 400+ partners in 3 years.", signal: "Fresh in role — 6 weeks. Building the team.", linkedin: "in/sarahchen" },
    { name: "Marcus Rivera", title: "Enterprise GTM Lead", background: "Ex-Databricks, Ex-Snowflake. Known for disciplined 'land and expand' motion.", signal: "Last two hires were both senior SEs.", linkedin: "in/mrivera" },
  ],
  whatJustHappened: [
    { text: "Posted 14 enterprise roles in the last 30 days — 8 in partnerships/channel.", tag: "fact", sources: [2, 7] },
    { text: "Published 'Claude for Work' case studies with 3 Fortune 500 cos on Apr 12.", tag: "fact", sources: [1, 3] },
    { text: "Dario tweeted signal quality is 'the last mile' bottleneck for enterprise deployment.", tag: "fact", sources: [4] },
    { text: "Bain report places Anthropic ahead of OpenAI on 'trust + compliance' dimension.", tag: "inference", sources: [5] },
  ],
  talkingPoints: [
    { text: "Open with the Dario tweet — signal quality is their self-identified bottleneck.", tag: "inference", sources: [4] },
    { text: "Position Relevant upstream of Claude: we deliver the decision-grade signal their customers want inside Claude.", tag: "inference", sources: [] },
    { text: "Reference Stripe's partner program — Sarah's playbook is partner-led distribution, not DIY.", tag: "fact", sources: [6] },
    { text: "Bring a one-page architecture diagram. Partnerships leads hate vague pitches.", tag: "inference", sources: [] },
  ],
  landmines: [
    { text: "Do not lead with 'AI-powered.' They build AI. It lands as naïve.", tag: "inference", sources: [] },
    { text: "Avoid any positioning as a competitor to Claude's built-in web search.", tag: "inference", sources: [8] },
    { text: "Their enterprise contract length is typically 24 months — don't propose a 3-month pilot.", tag: "fact", sources: [1, 3] },
  ],
  questions: [
    { text: "Where does Claude-for-Work stop, and where do you expect partners to begin?", tag: "inference", sources: [] },
    { text: "What does a 'partner that earned a Fortune 500 co-sell' look like, concretely, 12 months in?", tag: "inference", sources: [] },
    { text: "What's the most recent partnership you killed, and why?", tag: "inference", sources: [] },
    { text: "How is your team measuring attribution on partner-sourced deals right now?", tag: "inference", sources: [6] },
  ],
  competitors: [
    { text: "OpenAI's partner program remains self-serve; Anthropic is building a curated motion.", tag: "fact", sources: [5, 8] },
    { text: "Google Cloud's Gemini partner tier undercuts Anthropic on co-sell economics.", tag: "fact", sources: [5] },
  ],
  sources: [
    { id: 1, title: "Anthropic launches Claude for Work Enterprise", domain: "anthropic.com", date: "Apr 12, 2026", authority: 98, kind: "official" },
    { id: 2, title: "Anthropic careers — 14 open enterprise roles", domain: "anthropic.com/careers", date: "Apr 18, 2026", authority: 96, kind: "official" },
    { id: 3, title: "How Block deployed Claude for Work", domain: "block.xyz/engineering", date: "Apr 10, 2026", authority: 84, kind: "case-study" },
    { id: 4, title: "Dario Amodei on the enterprise AI last mile", domain: "x.com/darioamodei", date: "Apr 14, 2026", authority: 72, kind: "social" },
    { id: 5, title: "AI foundation model enterprise report Q1", domain: "bain.com", date: "Mar 31, 2026", authority: 94, kind: "analyst" },
    { id: 6, title: "Inside Stripe's partner program, 2019–2023", domain: "hbr.org", date: "Feb 2024", authority: 91, kind: "press" },
    { id: 7, title: "Anthropic hiring surge — enterprise focus", domain: "theinformation.com", date: "Apr 09, 2026", authority: 88, kind: "press" },
    { id: 8, title: "OpenAI vs Anthropic partner economics", domain: "stratechery.com", date: "Apr 01, 2026", authority: 86, kind: "analyst" },
  ],
  runMeta: {
    sources: 8,
    queries: 23,
    time: "1m 47s",
    evidence: { official: 2, press: 2, analyst: 2, social: 1, caseStudy: 1 },
  },
};

const FEED_SIGNALS = [
  { id: 1, trajectory: "ESCALATING", headline: "Anthropic drops Claude for Work Enterprise — 3 Fortune 500 case studies published", synthesis: "Signals aggressive enterprise GTM push. Changes competitive calculus for any tool positioning near Claude.", sources: 7, date: "2h ago", hot: true, consequence: ["competitive", "opportunity"], domains: ["anthropic.com", "wsj.com", "theinformation.com"], score: 94 },
  { id: 2, trajectory: "EMERGING", headline: "EU AI Act Article 6 guidance lands — general-purpose model obligations narrowed", synthesis: "Compliance scope tightened. Removes a 6-month overhang for model providers shipping into Europe.", sources: 11, date: "5h ago", hot: false, consequence: ["risk", "strategic"], domains: ["europa.eu", "ft.com", "reuters.com"], score: 88 },
  { id: 3, trajectory: "DEVELOPING", headline: "Stripe launches agent payments API — early partners include Rippling, Ramp", synthesis: "First mainstream infra for autonomous agent spend. Unlocks a category of product ideas that were blocked on rails.", sources: 5, date: "9h ago", hot: true, consequence: ["opportunity"], domains: ["stripe.com", "techcrunch.com"], score: 82 },
  { id: 4, trajectory: "STABLE", headline: "OpenAI's enterprise revenue run-rate reportedly crosses $6B", synthesis: "Confirms market size for enterprise AI is materially bigger than it was 90 days ago. Recalibrates any TAM slide built before Q1.", sources: 9, date: "Yesterday", hot: false, consequence: ["strategic"], domains: ["theinformation.com", "ft.com"], score: 77 },
  { id: 5, trajectory: "FADING", headline: "LangChain layoffs — 25% headcount reduction, consolidation to LangSmith", synthesis: "Orchestration framework market consolidating. If you're building on LangChain, time to evaluate exit paths.", sources: 4, date: "Yesterday", hot: false, consequence: ["risk"], domains: ["theinformation.com", "x.com"], score: 68 },
  { id: 6, trajectory: "EMERGING", headline: "Cursor raises $900M at $9B — Anysphere valuation 3x in 90 days", synthesis: "Coding agents category is consolidating around 2–3 winners. Funding this pace = existential pressure on Copilot GTM.", sources: 6, date: "2d ago", hot: true, consequence: ["competitive", "opportunity"], domains: ["cursor.sh", "forbes.com", "techcrunch.com"], score: 91 },
];

const TICKER = [
  { label: "ANTHROPIC", value: "+18%", kind: "up", note: "enterprise roles w/w" },
  { label: "OPENAI ARR", value: "$6.0B", kind: "up", note: "run-rate · Q1" },
  { label: "EU AI ACT", value: "LIVE", kind: "neutral", note: "Art. 6 guidance" },
  { label: "CURSOR", value: "$9.0B", kind: "up", note: "Series E" },
  { label: "LANGCHAIN", value: "−25%", kind: "down", note: "headcount" },
  { label: "STRIPE", value: "SHIP", kind: "neutral", note: "agent payments" },
  { label: "SIGNAL RATE", value: "0.7/hr", kind: "neutral", note: "your lens" },
  { label: "NOISE FILTER", value: "94.2%", kind: "up", note: "rejected" },
];

// ───────────────────────── Primitive UI ─────────────────────────

const Kicker = ({ children, color }) => (
  <div className="mono" style={{ fontSize: 10, fontWeight: 500, letterSpacing: "0.16em", textTransform: "uppercase", color: color || "var(--ink-muted)" }}>
    {children}
  </div>
);

const Pill = ({ children, color, bg, border, size = "sm" }) => (
  <span className="mono" style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    height: size === "sm" ? 20 : 24, padding: size === "sm" ? "0 7px" : "0 9px",
    fontSize: size === "sm" ? 10 : 11, fontWeight: 500, letterSpacing: "0.08em", textTransform: "uppercase",
    color: color || "var(--ink-dim)", background: bg || "var(--surface)", border: `1px solid ${border || "var(--border)"}`,
    borderRadius: 4,
  }}>{children}</span>
);

const Dot = ({ color, size = 6, pulse }) => (
  <span className={pulse ? "live-dot" : ""} style={{ display: "inline-block", width: size, height: size, borderRadius: "50%", background: color }} />
);

const Btn = ({ children, variant = "ghost", size = "md", icon, onClick, style }) => {
  const base = {
    display: "inline-flex", alignItems: "center", gap: 8,
    height: size === "sm" ? 28 : size === "lg" ? 42 : 34,
    padding: size === "sm" ? "0 10px" : size === "lg" ? "0 16px" : "0 12px",
    borderRadius: 8, fontSize: size === "sm" ? 12 : 13, fontWeight: 500,
    transition: "all 0.15s ease", whiteSpace: "nowrap",
  };
  const variants = {
    primary: { background: "var(--ink)", color: "var(--bg)", border: "1px solid var(--ink)" },
    amber:   { background: "var(--amber)", color: "#0a0a0a", border: "1px solid var(--amber)" },
    ghost:   { background: "transparent", color: "var(--ink-dim)", border: "1px solid var(--border)" },
    solid:   { background: "var(--surface)", color: "var(--ink)", border: "1px solid var(--border)" },
    link:    { background: "transparent", color: "var(--ink-dim)", border: "0" },
  };
  return (
    <button onClick={onClick} style={{ ...base, ...variants[variant], ...style }}>
      {icon}
      {children}
    </button>
  );
};

const Card = ({ children, style, bg = "var(--bg-elev)", pad = 20, rounded = 12 }) => (
  <div style={{ background: bg, border: "1px solid var(--border)", borderRadius: rounded, padding: pad, ...style }}>
    {children}
  </div>
);

// Evidence chip — inline fact/inference marker
const EvTag = ({ type, sources }) => {
  const isFact = type === "fact";
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
      <span className="mono" style={{
        fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase",
        padding: "1px 5px", borderRadius: 3,
        color: isFact ? "var(--green)" : "var(--violet)",
        background: isFact ? "var(--green-soft)" : "oklch(0.72 0.14 290 / 0.12)",
        border: `1px solid ${isFact ? "var(--green)" : "var(--violet)"}33`,
      }}>{isFact ? "FACT" : "INFER"}</span>
      {sources && sources.length > 0 && sources.map(s => (
        <span key={s} className="mono" style={{
          fontSize: 9, letterSpacing: "0.06em", padding: "1px 4px", borderRadius: 3,
          color: "var(--ink-muted)", background: "var(--surface)", border: "1px solid var(--border)",
          cursor: "pointer",
        }}>[{s}]</span>
      ))}
    </span>
  );
};

// Confidence meter bar
const Meter = ({ value = 0.8, label, color = "var(--green)", w = 120 }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
    {label && <span className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</span>}
    <div style={{ width: w, height: 4, background: "var(--surface-2)", borderRadius: 2, overflow: "hidden" }}>
      <div style={{ width: `${value * 100}%`, height: "100%", background: color }} />
    </div>
    <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-dim)" }}>{Math.round(value * 100)}</span>
  </div>
);

// Logo chip — monogram
const LogoChip = ({ name, color = "var(--amber)", size = 28 }) => {
  const initials = name.split(" ").map(n => n[0]).slice(0, 2).join("");
  return (
    <div style={{
      width: size, height: size, borderRadius: 6,
      background: `color-mix(in oklch, ${color}, transparent 70%)`,
      border: `1px solid color-mix(in oklch, ${color}, transparent 40%)`,
      color: color,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "var(--font-mono)", fontSize: size * 0.38, fontWeight: 600, letterSpacing: 0,
    }}>{initials}</div>
  );
};

// Expose
Object.assign(window, { Icon, I, Kicker, Pill, Dot, Btn, Card, EvTag, Meter, LogoChip, MEETING_BRIEF, FEED_SIGNALS, TICKER });
