/* Intelligence result variants — Bloomberg, Apple, Hybrid */

// ───────────────────────── V1: BLOOMBERG (dense, data-forward) ─────────────────────────
function ResultBloomberg() {
  const b = MEETING_BRIEF;
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      {/* Ticker */}
      <div style={{ height: 28, background: "#000", borderBottom: "1px solid var(--border-strong)", overflow: "hidden", position: "relative" }}>
        <div className="marquee-track mono" style={{ fontSize: 11, color: "var(--ink-dim)", letterSpacing: "0.04em", whiteSpace: "nowrap", lineHeight: "28px" }}>
          {[...TICKER, ...TICKER].map((t, i) => (
            <span key={i} style={{ marginRight: 40 }}>
              <span style={{ color: "var(--ink-soft)" }}>{t.label}</span>{" "}
              <span style={{ color: t.kind === "up" ? "var(--green)" : t.kind === "down" ? "var(--red)" : "var(--amber)" }}>{t.value}</span>{" "}
              <span style={{ color: "var(--ink-muted)" }}>{t.note}</span>
              <span style={{ color: "var(--border-strong)", margin: "0 20px" }}>·</span>
            </span>
          ))}
        </div>
      </div>

      {/* Header row */}
      <div style={{ padding: "20px 28px 16px", borderBottom: "1px solid var(--border)", background: "var(--bg-elev)" }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 24 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 16, flexWrap: "wrap" }}>
            <span className="mono" style={{ fontSize: 11, color: "var(--amber)", letterSpacing: "0.12em" }}>MTG-PREP · ANTHR</span>
            <span style={{ fontSize: 24, fontWeight: 500, color: "var(--ink)" }}>Anthropic</span>
            <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", letterSpacing: "0.04em" }}>anthropic.com · Partner intro · 30min</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-soft)", letterSpacing: "0.08em" }}>GEN 18:47 UTC · 1m 47s</span>
            <Btn variant="ghost" size="sm" icon={<I.copy size={13} />}>Copy</Btn>
            <Btn variant="ghost" size="sm" icon={<I.download size={13} />}>Export</Btn>
            <Btn variant="ghost" size="sm" icon={<I.share size={13} />}>Share</Btn>
          </div>
        </div>
      </div>

      {/* Hero row: bottom line + stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ padding: "28px 28px 26px", borderRight: "1px solid var(--border)" }}>
          <Kicker>Bottom line</Kicker>
          <div style={{ fontSize: 22, lineHeight: 1.35, color: "var(--ink)", marginTop: 10, fontFamily: "var(--font-display)", letterSpacing: "-0.01em" }}>
            {b.bottomLine}
          </div>
          <div style={{ display: "flex", gap: 20, marginTop: 18, flexWrap: "wrap" }}>
            <div><Kicker>Confidence</Kicker><div style={{ marginTop: 6 }}><Meter value={0.88} color="var(--green)" w={80} /></div></div>
            <div><Kicker>Evidence</Kicker><div style={{ marginTop: 6 }}><Meter value={0.82} color="var(--amber)" w={80} /></div></div>
            <div><Kicker>Freshness</Kicker><div style={{ marginTop: 6 }}><Meter value={0.94} color="var(--green)" w={80} /></div></div>
          </div>
        </div>
        <div style={{ padding: "22px 24px", display: "flex", flexDirection: "column", justifyContent: "center", background: "var(--surface)" }}>
          <Kicker>Run stats</Kicker>
          <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[["Sources", b.runMeta.sources], ["Queries", b.runMeta.queries], ["Duration", b.runMeta.time], ["Buckets", "6/6"]].map(([k, v]) => (
              <div key={k}>
                <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", letterSpacing: "0.08em" }}>{k}</div>
                <div className="display tnum" style={{ fontSize: 22, marginTop: 2, color: "var(--ink)" }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Why + Snapshot row */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", borderBottom: "1px solid var(--border)" }}>
        <div style={{ padding: "22px 28px", borderRight: "1px solid var(--border)" }}>
          <Kicker color="var(--amber)">Why this matters to you</Kicker>
          <div style={{ fontSize: 15, color: "var(--ink-dim)", marginTop: 10, lineHeight: 1.55 }}>{b.why}</div>
        </div>
        <div style={{ padding: "22px 24px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <LogoChip name={b.account} color={b.snapshot.logoColor} size={26} />
            <Kicker>Snapshot</Kicker>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 6, columnGap: 16, fontSize: 12 }}>
            {[["Industry", b.snapshot.industry],["HQ", b.snapshot.hq],["Size", b.snapshot.size],["Funding", b.snapshot.funding],["CEO", b.snapshot.ceo]].map(([k, v]) => (
              <React.Fragment key={k}>
                <span className="mono" style={{ color: "var(--ink-muted)", letterSpacing: "0.04em" }}>{k}</span>
                <span style={{ color: "var(--ink)" }}>{v}</span>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Grid of findings */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderBottom: "1px solid var(--border)" }}>
        <SectionCol title="What just happened" icon={<I.up size={13} />} items={b.whatJustHappened} borderR />
        <SectionCol title="Talking points" icon={<I.flame size={13} />} items={b.talkingPoints} color="var(--amber)" />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderBottom: "1px solid var(--border)" }}>
        <SectionCol title="Landmines" icon={<I.warning size={13} />} items={b.landmines} color="var(--red)" borderR />
        <SectionCol title="Questions to ask" icon={<I.ask size={13} />} items={b.questions} color="var(--violet)" />
      </div>

      {/* People */}
      <div style={{ padding: "22px 28px", borderBottom: "1px solid var(--border)" }}>
        <Kicker>People in the room</Kicker>
        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--border)", border: "1px solid var(--border)", borderRadius: 8, overflow: "hidden" }}>
          {b.people.map((p) => (
            <div key={p.name} style={{ padding: "16px 18px", background: "var(--bg-elev)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{p.name}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 2 }}>{p.title}</div>
                </div>
                <a className="mono" style={{ fontSize: 10, color: "var(--amber)", letterSpacing: "0.04em" }}>{p.linkedin} ↗</a>
              </div>
              <div style={{ fontSize: 13, color: "var(--ink-dim)", marginTop: 10, lineHeight: 1.5 }}>{p.background}</div>
              <div style={{ marginTop: 10, padding: "7px 10px", background: "var(--amber-soft)", borderLeft: "2px solid var(--amber)", borderRadius: "0 4px 4px 0" }}>
                <span className="mono" style={{ fontSize: 10, color: "var(--amber)", letterSpacing: "0.08em" }}>SIGNAL · </span>
                <span style={{ fontSize: 12, color: "var(--ink-dim)" }}>{p.signal}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sources */}
      <SourcesBlock sources={b.sources} />
    </div>
  );
}

function SectionCol({ title, icon, items, color = "var(--ink)", borderR }) {
  return (
    <div style={{ padding: "22px 28px", borderRight: borderR ? "1px solid var(--border)" : "none" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
        <span style={{ color }}>{icon}</span>
        <Kicker color={color}>{title}</Kicker>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {items.map((x, i) => (
          <div key={i} style={{ display: "flex", gap: 12 }}>
            <span className="mono tnum" style={{ fontSize: 11, color: "var(--ink-soft)", paddingTop: 2, minWidth: 18 }}>{String(i + 1).padStart(2, "0")}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, color: "var(--ink)", lineHeight: 1.5 }}>{x.text}</div>
              <div style={{ marginTop: 6 }}><EvTag type={x.tag} sources={x.sources} /></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SourcesBlock({ sources }) {
  return (
    <div style={{ padding: "22px 28px", background: "var(--surface)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
        <Kicker>Sources · {sources.length}</Kicker>
        <div style={{ display: "flex", gap: 12, fontSize: 11 }}>
          {[["Official", 2, "var(--green)"],["Press", 2, "var(--amber)"],["Analyst", 2, "var(--violet)"],["Social", 1, "var(--ink-muted)"],["Case", 1, "var(--ink-muted)"]].map(([k, v, c]) => (
            <span key={k} className="mono" style={{ color: "var(--ink-muted)", letterSpacing: "0.04em" }}>
              <Dot color={c} size={6} /> {k} <span style={{ color: "var(--ink)" }}>{v}</span>
            </span>
          ))}
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--border)", border: "1px solid var(--border)", borderRadius: 6, overflow: "hidden" }}>
        {sources.map((s) => (
          <div key={s.id} style={{ padding: "10px 14px", background: "var(--bg-elev)", display: "flex", gap: 10, alignItems: "center" }}>
            <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-muted)", minWidth: 14 }}>{s.id}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, color: "var(--ink)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.title}</div>
              <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 2 }}>{s.domain} · {s.date}</div>
            </div>
            <span className="mono tnum" style={{ fontSize: 10, color: "var(--green)" }}>{s.authority}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ───────────────────────── V2: APPLE (editorial, spacious) ─────────────────────────
function ResultApple() {
  const b = MEETING_BRIEF;
  return (
    <div style={{ padding: "56px 56px 80px", maxWidth: 880, margin: "0 auto" }}>
      {/* toolbar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 48 }}>
        <div>
          <Kicker>Meeting prep · Apr 18, 2026</Kicker>
          <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", marginTop: 6 }}>1m 47s · 8 sources · personalized to Founder lens</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="ghost" size="sm" icon={<I.copy size={13} />}>Copy</Btn>
          <Btn variant="ghost" size="sm" icon={<I.download size={13} />}>PDF</Btn>
          <Btn variant="ghost" size="sm" icon={<I.share size={13} />}>Share</Btn>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 24 }}>
        <LogoChip name={b.account} color={b.snapshot.logoColor} size={40} />
        <div>
          <div style={{ fontSize: 14, color: "var(--ink-muted)" }}>You're meeting with</div>
          <div className="display" style={{ fontSize: 28, fontWeight: 400 }}>{b.account}</div>
        </div>
      </div>

      <h1 className="display" style={{ fontSize: 52, fontWeight: 400, lineHeight: 1.05, letterSpacing: "-0.02em", marginTop: 24 }}>
        {b.bottomLine}
      </h1>

      <div style={{ fontSize: 17, color: "var(--ink-dim)", lineHeight: 1.55, marginTop: 28, maxWidth: 660, paddingLeft: 20, borderLeft: "2px solid var(--amber)" }}>
        <span style={{ color: "var(--amber)", fontSize: 13, letterSpacing: "0.08em", textTransform: "uppercase", fontFamily: "var(--font-mono)", display: "block", marginBottom: 8 }}>Why this matters to you</span>
        {b.why}
      </div>

      <div style={{ display: "flex", gap: 32, marginTop: 36, paddingTop: 28, borderTop: "1px solid var(--border)" }}>
        <div><Kicker>Confidence</Kicker><div style={{ marginTop: 6 }}><Meter value={0.88} color="var(--green)" w={100} /></div></div>
        <div><Kicker>Evidence</Kicker><div style={{ marginTop: 6 }}><Meter value={0.82} color="var(--amber)" w={100} /></div></div>
        <div><Kicker>Freshness</Kicker><div style={{ marginTop: 6 }}><Meter value={0.94} color="var(--green)" w={100} /></div></div>
      </div>

      {/* Snapshot */}
      <section style={{ marginTop: 72 }}>
        <Kicker>01 · The company</Kicker>
        <h2 className="display" style={{ fontSize: 32, fontWeight: 400, marginTop: 6, marginBottom: 24 }}>Anthropic, in one paragraph.</h2>
        <p style={{ fontSize: 17, lineHeight: 1.6, color: "var(--ink-dim)", maxWidth: 640 }}>
          A {b.snapshot.industry} company headquartered in {b.snapshot.hq}, Anthropic has scaled to {b.snapshot.size} on the back of a {b.snapshot.funding} raise. CEO {b.snapshot.ceo} has been vocal about enterprise distribution as a 2026 priority — and {b.snapshot.recent.toLowerCase()} is the clearest signal yet.
        </p>
      </section>

      {/* Narrative sections */}
      <ApplePanel n="02" title="What just happened" items={b.whatJustHappened} />
      <ApplePanel n="03" title="Talking points" items={b.talkingPoints} accent="var(--amber)" />
      <ApplePanel n="04" title="Landmines to avoid" items={b.landmines} accent="var(--red)" />
      <ApplePanel n="05" title="Questions to ask" items={b.questions} accent="var(--violet)" />

      <section style={{ marginTop: 72 }}>
        <Kicker>06 · People in the room</Kicker>
        <h2 className="display" style={{ fontSize: 32, fontWeight: 400, marginTop: 6, marginBottom: 24 }}>Who you're talking to.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {b.people.map((p) => (
            <div key={p.name} style={{ padding: "28px 28px 24px", background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 14 }}>
              <div style={{ fontSize: 20, fontWeight: 500 }}>{p.name}</div>
              <div style={{ fontSize: 13, color: "var(--ink-muted)", marginTop: 4 }}>{p.title}</div>
              <p style={{ fontSize: 14, lineHeight: 1.55, color: "var(--ink-dim)", marginTop: 16 }}>{p.background}</p>
              <div style={{ marginTop: 16, fontSize: 13, color: "var(--amber)", fontStyle: "italic", fontFamily: "var(--font-display)" }}>
                "{p.signal}"
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Sources */}
      <section style={{ marginTop: 72, paddingTop: 36, borderTop: "1px solid var(--border)" }}>
        <Kicker>Sources</Kicker>
        <div style={{ marginTop: 18 }}>
          {b.sources.map((s) => (
            <div key={s.id} style={{ display: "flex", gap: 18, padding: "14px 0", borderBottom: "1px solid var(--border)" }}>
              <span className="mono tnum" style={{ fontSize: 12, color: "var(--ink-muted)", minWidth: 28, paddingTop: 2 }}>0{s.id}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, color: "var(--ink)" }}>{s.title}</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 4 }}>{s.domain} · {s.date} · authority {s.authority}</div>
              </div>
              <I.link size={14} stroke="var(--ink-muted)" />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function ApplePanel({ n, title, items, accent = "var(--ink)" }) {
  return (
    <section style={{ marginTop: 72 }}>
      <Kicker color={accent}>{n}</Kicker>
      <h2 className="display" style={{ fontSize: 32, fontWeight: 400, marginTop: 6, marginBottom: 24 }}>{title}.</h2>
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        {items.map((x, i) => (
          <div key={i} style={{ display: "flex", gap: 20, paddingBottom: 18, borderBottom: i < items.length - 1 ? "1px solid var(--border)" : "none" }}>
            <span className="display tnum" style={{ fontSize: 22, color: "var(--ink-soft)", fontWeight: 300, minWidth: 28 }}>{i + 1}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 17, color: "var(--ink)", lineHeight: 1.5, fontFamily: "var(--font-display)", letterSpacing: "-0.01em" }}>{x.text}</div>
              <div style={{ marginTop: 10 }}><EvTag type={x.tag} sources={x.sources} /></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ───────────────────────── V3: HYBRID (recommended) ─────────────────────────
function ResultHybrid() {
  const b = MEETING_BRIEF;
  return (
    <div>
      {/* Thin ticker */}
      <div style={{ height: 24, borderBottom: "1px solid var(--border)", overflow: "hidden", background: "var(--bg-elev)" }}>
        <div className="marquee-track mono" style={{ fontSize: 10, letterSpacing: "0.05em", whiteSpace: "nowrap", lineHeight: "24px" }}>
          {[...TICKER, ...TICKER].map((t, i) => (
            <span key={i} style={{ marginRight: 36 }}>
              <span style={{ color: "var(--ink-soft)" }}>{t.label}</span>{" "}
              <span style={{ color: t.kind === "up" ? "var(--green)" : t.kind === "down" ? "var(--red)" : "var(--amber)" }}>{t.value}</span>{" "}
              <span style={{ color: "var(--ink-muted)" }}>{t.note}</span>
              <span style={{ color: "var(--border)", margin: "0 18px" }}>·</span>
            </span>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "40px 40px 64px" }}>
        {/* Top row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)">Meeting prep · MTG-PREP-0417</Pill>
            <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>Generated 1m 47s ago · 8 sources</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn variant="ghost" size="sm" icon={<I.copy size={13} />}>Copy</Btn>
            <Btn variant="ghost" size="sm" icon={<I.download size={13} />}>Export</Btn>
            <Btn variant="amber" size="sm" icon={<I.share size={13} />}>Share</Btn>
          </div>
        </div>

        {/* Hero */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 28, alignItems: "start" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 24 }}>
              <LogoChip name={b.account} color={b.snapshot.logoColor} size={44} />
              <div>
                <div className="display" style={{ fontSize: 30, fontWeight: 400, letterSpacing: "-0.02em" }}>{b.account}</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 2 }}>{b.website} · {b.type} · 30min</div>
              </div>
            </div>
            <h1 className="display" style={{ fontSize: 38, fontWeight: 400, lineHeight: 1.12, letterSpacing: "-0.02em", color: "var(--ink)" }}>
              {b.bottomLine}
            </h1>
            <div style={{ marginTop: 22, padding: "16px 20px", background: "var(--amber-soft)", border: "1px solid color-mix(in oklch, var(--amber), transparent 70%)", borderLeft: "3px solid var(--amber)", borderRadius: 8 }}>
              <Kicker color="var(--amber)">Why this matters to you</Kicker>
              <div style={{ fontSize: 15, color: "var(--ink)", marginTop: 8, lineHeight: 1.5 }}>{b.why}</div>
            </div>
          </div>
          <Card pad={0}>
            <div style={{ padding: "16px 18px", borderBottom: "1px solid var(--border)" }}>
              <Kicker>Company snapshot</Kicker>
            </div>
            <div style={{ padding: "16px 18px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 10, columnGap: 14, fontSize: 12 }}>
                {[["Industry", b.snapshot.industry],["HQ", b.snapshot.hq],["Size", b.snapshot.size],["Funding", b.snapshot.funding],["CEO", b.snapshot.ceo]].map(([k, v]) => (
                  <React.Fragment key={k}>
                    <span className="mono" style={{ color: "var(--ink-muted)", letterSpacing: "0.04em" }}>{k}</span>
                    <span style={{ color: "var(--ink)" }}>{v}</span>
                  </React.Fragment>
                ))}
              </div>
              <div style={{ marginTop: 14, padding: "8px 10px", background: "var(--surface)", borderRadius: 6, fontSize: 11 }}>
                <span className="mono" style={{ color: "var(--amber)", letterSpacing: "0.08em" }}>RECENT · </span>
                <span style={{ color: "var(--ink-dim)" }}>{b.snapshot.recent}</span>
              </div>
            </div>
            <div style={{ padding: "14px 18px", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "space-between" }}>
              <div><Kicker>Conf</Kicker><div style={{ marginTop: 4 }}><Meter value={0.88} color="var(--green)" w={60} /></div></div>
              <div><Kicker>Evid</Kicker><div style={{ marginTop: 4 }}><Meter value={0.82} color="var(--amber)" w={60} /></div></div>
            </div>
          </Card>
        </div>

        {/* Bento */}
        <div style={{ marginTop: 32, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <BentoCard title="What just happened" icon={<I.up size={13} />} items={b.whatJustHappened} />
          <BentoCard title="Talking points" icon={<I.flame size={13} />} items={b.talkingPoints} accent="var(--amber)" />
          <BentoCard title="Landmines" icon={<I.warning size={13} />} items={b.landmines} accent="var(--red)" />
          <BentoCard title="Questions to ask" icon={<I.ask size={13} />} items={b.questions} accent="var(--violet)" />
        </div>

        {/* People */}
        <div style={{ marginTop: 16 }}>
          <Card pad={0}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10 }}>
              <I.users size={14} stroke="var(--green)" />
              <Kicker>People in the room</Kicker>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: "var(--border)" }}>
              {b.people.map((p) => (
                <div key={p.name} style={{ padding: "20px 22px", background: "var(--bg-elev)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 500 }}>{p.name}</div>
                      <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", marginTop: 2 }}>{p.title}</div>
                    </div>
                    <Pill color="var(--amber)" bg="var(--amber-soft)" border="var(--amber)">Attending</Pill>
                  </div>
                  <div style={{ fontSize: 13, color: "var(--ink-dim)", marginTop: 12, lineHeight: 1.5 }}>{p.background}</div>
                  <div style={{ marginTop: 12, padding: "8px 12px", background: "var(--surface)", borderLeft: "2px solid var(--amber)", borderRadius: "0 6px 6px 0", fontSize: 12 }}>
                    <span className="mono" style={{ fontSize: 10, color: "var(--amber)", letterSpacing: "0.08em" }}>SIGNAL · </span>
                    <span style={{ color: "var(--ink-dim)" }}>{p.signal}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Competitor context */}
        <div style={{ marginTop: 16 }}>
          <BentoCard title="Competitor context" icon={<I.swords size={13} />} items={b.competitors} accent="var(--green)" />
        </div>

        {/* Sources */}
        <div style={{ marginTop: 16 }}>
          <Card pad={0}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Kicker>Sources · {b.sources.length}</Kicker>
              <div style={{ display: "flex", gap: 10, fontSize: 10 }}>
                {[["Official", 2, "var(--green)"],["Press", 2, "var(--amber)"],["Analyst", 2, "var(--violet)"],["Social", 1, "var(--ink-muted)"],["Case", 1, "var(--ink-muted)"]].map(([k, v, c]) => (
                  <span key={k} className="mono" style={{ color: "var(--ink-muted)", letterSpacing: "0.04em", display: "inline-flex", alignItems: "center", gap: 5 }}>
                    <Dot color={c} size={5} /> {k} <span style={{ color: "var(--ink)" }}>{v}</span>
                  </span>
                ))}
              </div>
            </div>
            <div>
              {b.sources.map((s, i) => (
                <div key={s.id} style={{ padding: "12px 20px", borderBottom: i < b.sources.length - 1 ? "1px solid var(--border)" : "none", display: "flex", gap: 14, alignItems: "center" }}>
                  <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-muted)", minWidth: 18 }}>[{s.id}]</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: "var(--ink)" }}>{s.title}</div>
                    <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 2 }}>{s.domain} · {s.date}</div>
                  </div>
                  <Pill color={s.kind === "official" ? "var(--green)" : s.kind === "analyst" ? "var(--violet)" : "var(--amber)"}>{s.kind}</Pill>
                  <span className="mono tnum" style={{ fontSize: 11, color: "var(--green)", minWidth: 28, textAlign: "right" }}>{s.authority}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Follow-up chat */}
        <div style={{ marginTop: 16 }}>
          <Card pad={0}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10 }}>
              <I.ask size={14} stroke="var(--amber)" />
              <Kicker>Ask follow-up</Kicker>
            </div>
            <div style={{ padding: "16px 20px", display: "flex", flexDirection: "column", gap: 10 }}>
              {["Turn this into 5 talking points for my VP.", "What objections should I expect?", "One-page brief I can send before the call."].map((q) => (
                <button key={q} style={{ padding: "10px 14px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, color: "var(--ink-dim)", textAlign: "left", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span>{q}</span><I.arrowR size={13} stroke="var(--ink-muted)" />
                </button>
              ))}
              <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
                <input placeholder="Ask anything about this brief..." style={{ flex: 1, background: "var(--bg-elev)", border: "1px solid var(--border)", borderRadius: 8, padding: "11px 14px", color: "var(--ink)", fontSize: 14, outline: "none" }} />
                <Btn variant="amber" icon={<I.arrowR size={13} />}>Ask</Btn>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function BentoCard({ title, icon, items, accent = "var(--ink)" }) {
  return (
    <Card pad={0}>
      <div style={{ padding: "12px 18px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ color: accent }}>{icon}</span>
        <Kicker color={accent}>{title}</Kicker>
      </div>
      <div style={{ padding: "14px 18px 16px" }}>
        {items.map((x, i) => (
          <div key={i} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: i < items.length - 1 ? "1px solid var(--border)" : "none" }}>
            <span className="mono tnum" style={{ fontSize: 10, color: "var(--ink-soft)", paddingTop: 3, minWidth: 16 }}>{String(i + 1).padStart(2, "0")}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, color: "var(--ink)", lineHeight: 1.5 }}>{x.text}</div>
              <div style={{ marginTop: 6 }}><EvTag type={x.tag} sources={x.sources} /></div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

Object.assign(window, { ResultBloomberg, ResultApple, ResultHybrid });
